# Determinism analysis

## Assessment
Corregir primero escritura canónica y trazabilidad; directo o delegado pueden funcionar. El subagente no es la causa del defecto.

El prepass execution-deps devuelve cero stages/edges/issues: no representa el flujo textual ni prueba ausencia de dependencia. Se revisó fuente. Principios BMAD dicen subagents CANNOT spawn, pero esa es una premisa portable de la guía, no una restricción de las herramientas actuales: aquí hay anidamiento y cuatro slots. No hubo benchmarking ni ejecución de los workflows; impacto temporal, tokens y calidad son hipótesis. No se imputan paths absolutos de .analysis ni ausencia de títulos ingleses a defectos funcionales.

## Existing scripts inventory
No existen scripts propios en estos wrappers (prepass scripts-temp sin findings). Dependencias BMAD ya contienen resolve_customization.py, render_skill.py y memlog.py: reutilizar, no duplicar.

## Script findings

### **[LOW] Validación mecánica de contrato**
SKILL.md:12-20,43: resolver referencia explícita y validar cobertura exacta de IDs es plumbing para Python; decidir rechazo o si minor agrega alcance queda en LLM. Banda de impuesto LLM estimada light (<100 tokens por comprobación pequeña); ahorro agregado no cuantificado sin tamaño de entradas y medición. Python stdlib, prepass posible para rutas/IDs.

## Distribution findings

### **[MEDIUM] Lectura previa completa para resolver una referencia**

SKILL.md:17,26. Principal lee spec por referencia y el arquitecto la lee de nuevo. Extraer referencia concreta y paths; delegar análisis completo. Si documento pequeño, ejecución directa también es razonable. Impacto: hipotético ahorro de contexto/coordinación, sin medición.

### **[MEDIUM] Retorno sin formato exclusivo**

SKILL.md:39,45. Fijar salida compacta con path, IDs y pendientes, reservando preguntas a mensajes al principal. Impacto: hipotético ahorro de contexto/coordinación, sin medición.

## Aggregate token savings
No estimación numérica defendible: no hay benchmarks, entradas representativas ni conteo por invocación.

## Strengths
Prioridad explícita de review, no genera otra review, protege decisiones del usuario y mantiene IDs.
