#!/usr/bin/env python3
"""Propone las ramas publicables del proyecto, para elegir que publicar con publicar.py.

Fuentes:
  gitlab  usa el skill `gitlab-connect` (API v4 /repository/branches): trae fecha del
          ultimo commit, autor, merged y protected. Requiere GITLAB_BASE_URL y
          GITLAB_TOKEN en el `.env` del proyecto, y un project_id.
  git     usa `git ls-remote --heads origin`: solo nombres + sha, sin credenciales.
  auto    intenta gitlab y cae a git si no hay credenciales/project_id (default).
"""
from __future__ import annotations

import argparse
import json
import sys

from webhook_api import (
    CyberPublishError,
    cargar_gitlab_client,
    nombre_repo,
    rama_actual,
    ramas_en_origin,
    proyecto_configurado,
)


def _resolver_project_id(client, explicito: str | None, proyecto: str | None) -> tuple[str, str | None]:
    if explicito:
        return explicito, proyecto
    nombre, cfg, _ = proyecto_configurado(proyecto=proyecto)
    desde_config = str((cfg.get("gitlab") or {}).get("project_id") or "")
    if desde_config:
        return desde_config, nombre
    # Ultimo recurso: buscar el proyecto por el nombre del repo local.
    repo = nombre_repo()
    encontrados = client.get(
        "/projects", query={"membership": "true", "search": repo, "simple": "true", "per_page": 20}
    )
    exactos = [p for p in encontrados if (p.get("path") or "") == repo]
    if len(exactos) == 1:
        return str(exactos[0]["id"]), repo
    if not encontrados:
        raise CyberPublishError(
            f"GitLab no devolvio proyectos que matcheen '{repo}'. Pasa --project-id o "
            f"guardalo con config_proyecto.py set --gitlab-project-id <id>."
        )
    detalle = ", ".join(f"{p['id']}={p.get('path_with_namespace')}" for p in encontrados[:10])
    raise CyberPublishError(
        f"'{repo}' matchea varios proyectos GitLab: {detalle}. Elige con "
        f"config_proyecto.py set --gitlab-project-id <id>."
    )


def ramas_gitlab(project_id: str | None, filtro: str | None, proyecto: str | None) -> dict:
    client, api_path = cargar_gitlab_client()
    pid, proyecto_resuelto = _resolver_project_id(client, project_id, proyecto)
    crudas = client.list_project_branches(pid, search=filtro)
    ramas = [
        {
            "name": b.get("name"),
            "committed_date": (b.get("commit") or {}).get("committed_date"),
            "author": (b.get("commit") or {}).get("author_name"),
            "short_id": (b.get("commit") or {}).get("short_id"),
            "title": (b.get("commit") or {}).get("title"),
            "merged": b.get("merged"),
            "protected": b.get("protected"),
            "default": b.get("default"),
        }
        for b in crudas
    ]
    ramas.sort(key=lambda b: b["committed_date"] or "", reverse=True)
    return {
        "fuente": "gitlab",
        "proyecto": proyecto_resuelto,
        "project_id": pid,
        "gitlab_api": str(api_path),
        "ramas": ramas,
    }


def ramas_git(filtro: str | None) -> dict:
    ramas = ramas_en_origin()
    if filtro:
        ramas = [r for r in ramas if filtro.lower() in r["name"].lower()]
    ramas.sort(key=lambda r: r["name"])
    return {"fuente": "git", "project_id": None, "ramas": ramas}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--fuente", choices=("auto", "gitlab", "git"), default="auto")
    parser.add_argument("--proyecto", help="nombre del proyecto configurado en .cyber-publish.json")
    parser.add_argument("--project-id", help="project_id de GitLab (default: config o busqueda)")
    parser.add_argument("--filtro", help="substring del nombre de rama")
    parser.add_argument("--limite", type=int, default=20, help="0 = sin limite")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    aviso = ""
    if args.fuente == "gitlab":
        datos = ramas_gitlab(args.project_id, args.filtro, args.proyecto)
    elif args.fuente == "git":
        datos = ramas_git(args.filtro)
    else:
        try:
            datos = ramas_gitlab(args.project_id, args.filtro, args.proyecto)
        except CyberPublishError as exc:
            aviso = f"gitlab no disponible ({exc}) -> fallback a origin"
            datos = ramas_git(args.filtro)

    try:
        actual = rama_actual()
    except CyberPublishError:
        actual = None

    total = len(datos["ramas"])
    ramas = datos["ramas"] if args.limite <= 0 else datos["ramas"][: args.limite]
    datos.update({"repo": nombre_repo(), "rama_actual": actual, "total": total, "ramas": ramas})
    if aviso:
        datos["aviso"] = aviso

    if args.json:
        print(json.dumps(datos, ensure_ascii=False, indent=2))
        return 0

    if aviso:
        print(f"[aviso] {aviso}", file=sys.stderr)
    print(f"repo     : {datos['repo']}")
    print(f"fuente   : {datos['fuente']}" + (f" (project {datos['project_id']})" if datos["project_id"] else ""))
    print(f"actual   : {actual or '(sin rama)'}")
    print(f"ramas    : {len(ramas)}/{total}")
    for rama in ramas:
        marca = "*" if rama["name"] == actual else " "
        fecha = (rama.get("committed_date") or "")[:10]
        etiquetas = "".join(
            [
                " [default]" if rama.get("default") else "",
                " [merged]" if rama.get("merged") else "",
                " [protected]" if rama.get("protected") else "",
            ]
        )
        extra = f"  {fecha}  {rama.get('author') or ''}".rstrip()
        print(f" {marca} {rama['name']}{etiquetas}{extra}")
    print("\nPublicar una: publicar.py --env qa --rama <nombre> --apply")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except CyberPublishError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(1)
