#!/usr/bin/env python3
"""Lista los ambientes publicados por cada servidor webhook y los guarda en assets/ambientes.json."""
from __future__ import annotations

import argparse
import json
import sys

from webhook_api import (
    AMBIENTES_JSON,
    CyberPublishError,
    WebhookClient,
    cargar_inventario,
    cargar_servidores,
    escribir_json,
)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--servidor",
        action="append",
        dest="servidores",
        help="limita a un servidor (repetible). Por defecto: todos los de servidores.json",
    )
    parser.add_argument("--filtro", help="substring para filtrar la salida impresa")
    parser.add_argument(
        "--cache",
        action="store_true",
        help="no consulta la red: imprime lo que ya esta en ambientes.json",
    )
    parser.add_argument("--json", action="store_true", help="imprime JSON en vez de tabla")
    args = parser.parse_args()

    conocidos = cargar_servidores()
    objetivo = args.servidores or sorted(conocidos)

    if args.cache:
        inventario = cargar_inventario()
    else:
        inventario = {"servidores": {}}
        for nombre in objetivo:
            client = WebhookClient.desde_nombre(nombre)
            _, ambientes = client.leer_formulario()
            inventario["servidores"][nombre] = {
                "base_url": client.base_url,
                "formulario": client.url_formulario,
                "validacion": client.url_validacion,
                "total": len(ambientes),
                "ambientes": ambientes,
            }
            print(f"[ok] {nombre}: {len(ambientes)} ambientes", file=sys.stderr)
        # Si se listo solo un servidor, preserva los demas del inventario previo.
        if AMBIENTES_JSON.exists() and len(objetivo) < len(conocidos):
            previo = cargar_inventario().get("servidores", {})
            for nombre, datos in previo.items():
                inventario["servidores"].setdefault(nombre, datos)
        escribir_json(AMBIENTES_JSON, inventario)
        print(f"[ok] guardado en {AMBIENTES_JSON}", file=sys.stderr)

    if args.json:
        print(json.dumps(inventario, ensure_ascii=False, indent=2))
        return 0

    for nombre in sorted(inventario["servidores"]):
        datos = inventario["servidores"][nombre]
        ambientes = datos["ambientes"]
        if args.filtro:
            ambientes = [a for a in ambientes if args.filtro.lower() in a.lower()]
        print(f"\n== {nombre} ({datos['base_url']}) — {len(ambientes)}/{datos['total']}")
        for ambiente in ambientes:
            print(f"  {ambiente}")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except CyberPublishError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(1)
