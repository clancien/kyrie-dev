#!/usr/bin/env python3
"""Lee/escribe `.cyber-publish.json`: que ambiente dev y que ambiente qa tiene este proyecto.

Subcomandos:
  show      imprime la config del proyecto. Sale con codigo 3 si falta (=> preguntar al usuario).
  sugerir   propone candidatos dev/qa cruzando el nombre del repo con assets/ambientes.json.
  set       guarda la eleccion del usuario.
"""
from __future__ import annotations

import argparse
import difflib
import json
import re
import sys
from pathlib import Path

from webhook_api import (
    ENTORNOS,
    ConfigFaltante,
    CyberPublishError,
    ambientes_de_servidor,
    cargar_config,
    escribir_json,
    configuracion_normalizada,
    nombre_repo,
    proyecto_configurado,
    ruta_config,
)

CODIGO_CONFIG_FALTANTE = 3


def _tokens(texto: str) -> list[str]:
    return [t for t in re.split(r"[^a-z0-9]+", texto.lower()) if t]


def _base_sin_prefijo(ambiente: str) -> tuple[str, str]:
    """('dcybercenter-oit.cc.cl') -> ('dev', 'cybercenter-oit')."""
    base = re.sub(r"\.cc\.cl$", "", ambiente)
    if base.startswith("t2"):
        return "qa", base[2:]
    if base.startswith("t"):
        return "qa", base[1:]
    if base.startswith("d"):
        return "dev", base[1:]
    return "prod", base


def sugerencias(repo: str, limite: int = 5) -> dict[str, list[dict]]:
    from webhook_api import cargar_inventario

    inventario = cargar_inventario()
    repo_tokens = set(_tokens(repo))
    resultado: dict[str, list[dict]] = {"dev": [], "qa": []}
    puntuados: list[tuple[float, str, str, str]] = []
    for servidor, datos in inventario["servidores"].items():
        for ambiente in datos["ambientes"]:
            entorno, base = _base_sin_prefijo(ambiente)
            if entorno not in resultado:
                continue
            base_tokens = set(_tokens(base))
            comunes = len(repo_tokens & base_tokens)
            ratio = difflib.SequenceMatcher(None, repo.lower(), base).ratio()
            puntuados.append((comunes * 2 + ratio, entorno, servidor, ambiente))
    puntuados.sort(reverse=True)
    for score, entorno, servidor, ambiente in puntuados:
        if len(resultado[entorno]) < limite:
            resultado[entorno].append(
                {"servidor": servidor, "ambiente": ambiente, "score": round(score, 3)}
            )
    return resultado


def _detalle_proyecto(nombre: str, cfg: dict) -> list[str]:
    lineas = [f"proyecto  : {nombre}"]
    for entorno in ENTORNOS:
        entrada = (cfg.get("ambientes") or {}).get(entorno) or {}
        if entrada:
            lineas.append(f"{entorno:<9} : {entrada['ambiente']}  @{entrada['servidor']}")
        else:
            lineas.append(f"{entorno:<9} : (sin configurar)")
    pid = (cfg.get("gitlab") or {}).get("project_id")
    lineas.append(f"gitlab    : project_id {pid}" if pid else "gitlab    : (sin project_id)")
    return lineas


def cmd_show(args) -> int:
    try:
        data = configuracion_normalizada()
    except ConfigFaltante as exc:
        print(str(exc), file=sys.stderr)
        print(
            "Sugerencias para preguntarle al usuario:\n"
            + json.dumps(sugerencias(nombre_repo()), ensure_ascii=False, indent=2),
            file=sys.stderr,
        )
        return CODIGO_CONFIG_FALTANTE
    if args.json:
        if args.proyecto:
            nombre, cfg, _ = proyecto_configurado(proyecto=args.proyecto)
            print(json.dumps({"proyecto": nombre, **cfg}, ensure_ascii=False, indent=2))
        else:
            print(json.dumps(data, ensure_ascii=False, indent=2))
    else:
        print(f"config    : {ruta_config()}")
        proyectos = data.get("proyectos", {})
        if args.proyecto:
            nombre, cfg, _ = proyecto_configurado(proyecto=args.proyecto)
            for linea in _detalle_proyecto(nombre, cfg):
                print(linea)
        elif len(proyectos) == 1:
            nombre, cfg = next(iter(proyectos.items()))
            for linea in _detalle_proyecto(nombre, cfg):
                print(linea)
        else:
            default_project = data.get("default_project")
            print(f"default   : {default_project or '(sin default)'}")
            print(f"proyectos : {len(proyectos)}")
            for nombre, cfg in proyectos.items():
                marca = "*" if nombre == default_project else "-"
                print(f"{marca} {nombre}")
                for linea in _detalle_proyecto(nombre, cfg)[1:]:
                    print(f"  {linea}")
    return 0


def cmd_sugerir(args) -> int:
    repo = args.repo or nombre_repo()
    print(json.dumps({"repo": repo, **sugerencias(repo, args.limite)}, ensure_ascii=False, indent=2))
    return 0


def _validar(servidor: str, ambiente: str) -> None:
    disponibles = ambientes_de_servidor(servidor)
    if ambiente not in disponibles:
        cercanos = difflib.get_close_matches(ambiente, disponibles, n=5, cutoff=0.5)
        raise CyberPublishError(
            f"'{ambiente}' no existe en {servidor}. "
            + (f"Parecidos: {', '.join(cercanos)}" if cercanos else "Revisa listar_ambientes.py")
        )


def cmd_set(args) -> int:
    path = ruta_config()
    if path.exists():
        data = configuracion_normalizada()
    else:
        data = {"version": 2, "default_project": None, "proyectos": {}}
    proyectos = data.setdefault("proyectos", {})

    if args.proyecto:
        proyecto = args.proyecto
    elif proyectos:
        default_project = data.get("default_project")
        if default_project and default_project in proyectos:
            proyecto = default_project
        elif len(proyectos) == 1:
            proyecto = next(iter(proyectos))
        else:
            raise CyberPublishError(
                "Hay varios proyectos configurados. Usa --proyecto <nombre> para elegir uno."
            )
    else:
        proyecto = nombre_repo()

    cfg = proyectos.setdefault(proyecto, {})
    cfg.setdefault("ambientes", {})
    if args.gitlab_project_id:
        cfg.setdefault("gitlab", {})["project_id"] = str(args.gitlab_project_id)

    for entorno in ENTORNOS:
        valor = getattr(args, entorno)
        if not valor:
            continue
        servidor, _, ambiente = valor.partition(":")
        if not ambiente:
            raise CyberPublishError(
                f"--{entorno} espera 'servidor:ambiente' (ej: tatenen:tcybercenter-oit.cc.cl)"
            )
        _validar(servidor, ambiente)
        cfg["ambientes"][entorno] = {"servidor": servidor, "ambiente": ambiente}

    if not cfg["ambientes"] and not cfg.get("gitlab"):
        raise CyberPublishError("Nada que guardar: pasa --dev, --qa y/o --gitlab-project-id.")

    data["version"] = 2
    data["default_project"] = proyecto
    escribir_json(path, data)
    print(f"[ok] guardado {path}")
    return cmd_show(argparse.Namespace(json=False, proyecto=proyecto))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_show = sub.add_parser("show", help="imprime la config (exit 3 si falta)")
    p_show.add_argument("--json", action="store_true")
    p_show.add_argument("--proyecto", help="mostrar un proyecto especifico")
    p_show.set_defaults(func=cmd_show)

    p_sug = sub.add_parser("sugerir", help="candidatos dev/qa segun el nombre del repo")
    p_sug.add_argument("--repo", help="nombre a comparar (default: remote origin del repo)")
    p_sug.add_argument("--limite", type=int, default=5)
    p_sug.set_defaults(func=cmd_sugerir)

    p_set = sub.add_parser("set", help="guarda la eleccion del usuario")
    p_set.add_argument("--dev", help="servidor:ambiente (ej: tatenen:dcybercenter-oit.cc.cl)")
    p_set.add_argument("--qa", help="servidor:ambiente (ej: tatenen:tcybercenter-oit.cc.cl)")
    p_set.add_argument("--proyecto", help="etiqueta del proyecto")
    p_set.add_argument(
        "--gitlab-project-id",
        help="project_id de GitLab para que ramas.py proponga las ramas de este proyecto",
    )
    p_set.set_defaults(func=cmd_set)

    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except CyberPublishError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(1)
