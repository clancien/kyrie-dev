#!/usr/bin/env python3
"""Cliente del formulario "Ambiente / Rama" de los servidores webhook de Cybercenter.

El formulario vive en `<servidor>/ambiente/formulario` y postea a
`<servidor>/ambiente/validacion`. Ese endpoint NO es una previsualizacion:
ejecuta en el servidor `cd /internet/VDomain/<ambiente>`, fetch, descarta
cambios locales, checkout de la rama y pull. La respuesta 200 trae la salida
de consola dentro de un `<pre><code>` separada por `<br>`.
"""
from __future__ import annotations

import html
import json
import re
import subprocess
from dataclasses import dataclass
from pathlib import Path

import requests

ASSETS_DIR = Path(__file__).resolve().parent
SERVIDORES_JSON = ASSETS_DIR / "servidores.json"
AMBIENTES_JSON = ASSETS_DIR / "ambientes.json"

CONFIG_FILENAME = ".cyber-publish.json"
ENTORNOS = ("dev", "qa")
CONFIG_VERSION = 2

FORM_PATH = "/ambiente/formulario"
VALIDACION_PATH = "/ambiente/validacion"

RAMA_MIN = 3
RAMA_MAX = 200

# El GET del formulario es rapido; el POST corre git en el servidor.
TIMEOUT_GET = (15, 30)
TIMEOUT_POST = (15, 240)

DEFAULT_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:138.0) "
        "Gecko/20100101 Firefox/138.0"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "es-ES,es;q=0.8,en-US;q=0.5,en;q=0.3",
}


class CyberPublishError(RuntimeError):
    """Error de uso o de comunicacion con el servidor webhook."""


class ConfigFaltante(CyberPublishError):
    """El proyecto no tiene configurados sus ambientes dev/qa."""


# ---------------------------------------------------------------- servidores

def cargar_servidores() -> dict[str, str]:
    data = json.loads(SERVIDORES_JSON.read_text(encoding="utf-8"))
    return dict(data["servidores"])


def base_url_de(servidor: str) -> str:
    servidores = cargar_servidores()
    if servidor not in servidores:
        raise CyberPublishError(
            f"Servidor desconocido: {servidor}. Conocidos: {', '.join(sorted(servidores))}. "
            f"Agregalo en {SERVIDORES_JSON}."
        )
    return servidores[servidor].rstrip("/")


# -------------------------------------------------------------- parseo HTML

def extraer_token(html_text: str) -> str:
    match = re.search(r'name="_token"\s+value="([^"]+)"', html_text)
    if not match:
        raise CyberPublishError("No se encontro el _token CSRF en el formulario.")
    return match.group(1)


def extraer_ambientes(html_text: str) -> list[str]:
    bloque = re.search(
        r'<select[^>]*name="ambiente".*?</select>', html_text, flags=re.S
    )
    if not bloque:
        raise CyberPublishError("No se encontro el select de ambientes en el formulario.")
    valores = re.findall(r'<option value="([^"]*)"', bloque.group(0))
    return sorted({v for v in valores if v})


def extraer_consola(html_text: str) -> list[str]:
    """Devuelve la salida de consola del `<pre><code>` de la pagina de resultado."""
    bloque = re.search(r"<pre[^>]*>(.*?)</pre>", html_text, flags=re.S)
    if not bloque:
        return []
    cuerpo = re.sub(r"</?code[^>]*>", "", bloque.group(1))
    lineas = []
    for cruda in re.split(r"<br\s*/?>", cuerpo):
        texto = html.unescape(re.sub(r"<[^>]+>", "", cruda)).strip()
        if texto:
            lineas.append(texto)
    return lineas


# --------------------------------------------------------------- inventario

def cargar_inventario() -> dict:
    if not AMBIENTES_JSON.exists():
        raise CyberPublishError(
            f"No existe {AMBIENTES_JSON}. Ejecuta primero listar_ambientes.py."
        )
    return json.loads(AMBIENTES_JSON.read_text(encoding="utf-8"))


def ambientes_de_servidor(servidor: str) -> list[str]:
    inventario = cargar_inventario()
    entrada = inventario.get("servidores", {}).get(servidor)
    if entrada is None:
        raise CyberPublishError(
            f"El inventario no tiene datos de '{servidor}'. Re-ejecuta listar_ambientes.py."
        )
    return list(entrada.get("ambientes", []))


def escribir_json(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


# ---------------------------------------------------------------------- git

def _git(args: list[str], cwd: Path) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["git", *args], cwd=cwd, capture_output=True, text=True, check=False
    )


def raiz_proyecto(cwd: Path | None = None) -> Path:
    cwd = cwd or Path.cwd()
    res = _git(["rev-parse", "--show-toplevel"], cwd)
    if res.returncode != 0:
        raise CyberPublishError(f"{cwd} no es un repositorio git.")
    return Path(res.stdout.strip())


def rama_actual(cwd: Path | None = None) -> str:
    cwd = cwd or Path.cwd()
    # symbolic-ref funciona incluso en un repo sin commits; rev-parse no.
    res = _git(["symbolic-ref", "--short", "HEAD"], cwd)
    if res.returncode != 0:
        raise CyberPublishError(
            "No hay rama actual (HEAD detached o repo invalido). Usa --rama <nombre>. "
            f"git dijo: {res.stderr.strip()}"
        )
    return res.stdout.strip()


def rama_existe_en_origin(rama: str, cwd: Path | None = None) -> bool:
    cwd = cwd or Path.cwd()
    res = _git(["ls-remote", "--heads", "origin", rama], cwd)
    if res.returncode != 0:
        raise CyberPublishError(
            f"No se pudo consultar origin: {res.stderr.strip() or res.stdout.strip()}"
        )
    return bool(res.stdout.strip())


def ramas_en_origin(cwd: Path | None = None) -> list[dict]:
    """Ramas del remote `origin` via git ls-remote (no necesita GitLab)."""
    cwd = cwd or Path.cwd()
    res = _git(["ls-remote", "--heads", "origin"], cwd)
    if res.returncode != 0:
        raise CyberPublishError(
            f"No se pudo consultar origin: {res.stderr.strip() or res.stdout.strip()}"
        )
    ramas = []
    for linea in res.stdout.splitlines():
        sha, _, ref = linea.partition("\t")
        if ref.startswith("refs/heads/"):
            ramas.append({"name": ref[len("refs/heads/"):], "short_id": sha[:8]})
    return ramas


def nombre_repo(cwd: Path | None = None) -> str:
    cwd = cwd or Path.cwd()
    res = _git(["remote", "get-url", "origin"], cwd)
    if res.returncode == 0 and res.stdout.strip():
        return re.sub(r"\.git$", "", res.stdout.strip().rstrip("/").split("/")[-1])
    return raiz_proyecto(cwd).name


# ------------------------------------------------------ config del proyecto

def ruta_config(cwd: Path | None = None) -> Path:
    return raiz_proyecto(cwd) / CONFIG_FILENAME


def cargar_config(cwd: Path | None = None) -> dict:
    path = ruta_config(cwd)
    if not path.exists():
        raise ConfigFaltante(
            f"CONFIG_FALTANTE: no existe {path}. Hay que preguntarle al usuario "
            f"que ambiente dev y que ambiente qa corresponden a este proyecto."
        )
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ConfigFaltante(f"CONFIG_FALTANTE: {path} no tiene un JSON valido de configuracion.")
    if not isinstance(data.get("proyectos"), dict) and not isinstance(data.get("ambientes"), dict):
        raise ConfigFaltante(
            f"CONFIG_FALTANTE: {path} no tiene la clave 'proyectos' ni 'ambientes'."
        )
    return data


def _config_a_v2(data: dict) -> dict:
    """Normaliza la configuracion a la forma v2 multi-proyecto."""
    proyectos = data.get("proyectos")
    if isinstance(proyectos, dict):
        normalizado: dict[str, dict] = {}
        for nombre, entrada in proyectos.items():
            if not isinstance(entrada, dict):
                continue
            item: dict = {}
            if isinstance(entrada.get("ambientes"), dict):
                item["ambientes"] = entrada["ambientes"]
            if isinstance(entrada.get("gitlab"), dict) and entrada["gitlab"]:
                item["gitlab"] = entrada["gitlab"]
            normalizado[str(nombre)] = item
        default_project = data.get("default_project")
        if default_project not in normalizado:
            default_project = None
        return {
            "version": int(data.get("version") or CONFIG_VERSION),
            "default_project": default_project,
            "proyectos": normalizado,
        }

    proyecto = str(data.get("proyecto") or nombre_repo())
    entrada: dict = {"ambientes": data.get("ambientes") or {}}
    if isinstance(data.get("gitlab"), dict) and data["gitlab"]:
        entrada["gitlab"] = data["gitlab"]
    return {
        "version": CONFIG_VERSION,
        "default_project": proyecto,
        "proyectos": {proyecto: entrada},
    }


def configuracion_normalizada(cwd: Path | None = None) -> dict:
    """Devuelve la configuracion del workspace en forma v2 multi-proyecto."""
    try:
        return _config_a_v2(cargar_config(cwd))
    except ConfigFaltante:
        raise


def proyecto_configurado(cwd: Path | None = None, proyecto: str | None = None) -> tuple[str, dict, dict]:
    """Resuelve el proyecto activo y devuelve (nombre, config, config_normalizada)."""
    data = configuracion_normalizada(cwd)
    proyectos = data.get("proyectos", {})
    if proyecto:
        if proyecto not in proyectos:
            raise ConfigFaltante(
                f"CONFIG_FALTANTE: el proyecto '{proyecto}' no esta configurado en {ruta_config(cwd)}."
            )
        return proyecto, proyectos[proyecto], data

    default_project = data.get("default_project")
    if default_project and default_project in proyectos:
        return default_project, proyectos[default_project], data

    if len(proyectos) == 1:
        nombre, cfg = next(iter(proyectos.items()))
        return nombre, cfg, data

    if not proyectos:
        raise ConfigFaltante(
            f"CONFIG_FALTANTE: no hay proyectos configurados en {ruta_config(cwd)}."
        )

    raise ConfigFaltante(
        f"CONFIG_FALTANTE: hay varios proyectos en {ruta_config(cwd)} y falta elegir uno."
    )


def gitlab_project_id(cwd: Path | None = None, proyecto: str | None = None) -> str:
    """project_id de GitLab del proyecto activo (o "" si no hay)."""
    try:
        _, cfg, _ = proyecto_configurado(cwd, proyecto=proyecto)
    except ConfigFaltante:
        return ""
    return str((cfg.get("gitlab") or {}).get("project_id") or "")


# ------------------------------------------- puente con el skill gitlab-connect

def localizar_gitlab_api(cwd: Path | None = None) -> Path:
    """Busca `assets/api.py` de gitlab-connect: skill hermano o instalado en el proyecto."""
    candidatos = [
        ASSETS_DIR.parent.parent / "gitlab-connect" / "assets" / "api.py",
        Path(__file__).parent.parent.parent / "gitlab-connect" / "assets" / "api.py",
    ]
    try:
        raiz = raiz_proyecto(cwd)
        candidatos += [
            raiz / ".agents" / "skills" / "gitlab-connect" / "assets" / "api.py",
            raiz / "agents" / "skills" / "gitlab-connect" / "assets" / "api.py",
        ]
    except CyberPublishError:
        pass
    for candidato in candidatos:
        if candidato.exists():
            return candidato
    raise CyberPublishError(
        "No se encontro el skill gitlab-connect (assets/api.py). Instalalo junto a "
        "cyber-publish o usa --fuente git."
    )


def cargar_gitlab_client(cwd: Path | None = None):
    """Importa GitLabClient de gitlab-connect y lo autentica con el .env del proyecto."""
    import importlib.util

    api_path = localizar_gitlab_api(cwd)
    spec = importlib.util.spec_from_file_location("gitlab_connect_api", api_path)
    if spec is None or spec.loader is None:
        raise CyberPublishError(f"No se pudo importar {api_path}")
    modulo = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(modulo)
    raiz = raiz_proyecto(cwd)
    try:
        return modulo.GitLabClient.from_project_root(raiz), api_path
    except RuntimeError as exc:
        raise CyberPublishError(
            f"gitlab-connect no pudo autenticar: {exc}. Define GITLAB_BASE_URL y "
            f"GITLAB_TOKEN en {raiz / '.env'} (ver gitlab-connect/references/env-vars.md) "
            f"o usa --fuente git."
        ) from exc


def entorno_config(entorno: str, cwd: Path | None = None, proyecto: str | None = None) -> dict:
    if entorno not in ENTORNOS:
        raise CyberPublishError(f"Entorno invalido: {entorno}. Usa uno de {ENTORNOS}.")
    _, cfg, _ = proyecto_configurado(cwd, proyecto=proyecto)
    entrada = (cfg.get("ambientes") or {}).get(entorno)
    if not entrada or not entrada.get("servidor") or not entrada.get("ambiente"):
        raise ConfigFaltante(
            f"CONFIG_FALTANTE: el entorno '{entorno}' no esta configurado en "
            f"{ruta_config(cwd)}. Preguntale al usuario y guardalo con config_proyecto.py set."
        )
    return entrada


# ------------------------------------------------------------------ cliente

@dataclass
class WebhookClient:
    servidor: str
    base_url: str

    def __post_init__(self) -> None:
        self.session = requests.Session()
        self.session.headers.update(DEFAULT_HEADERS)

    @classmethod
    def desde_nombre(cls, servidor: str) -> "WebhookClient":
        return cls(servidor=servidor, base_url=base_url_de(servidor))

    @property
    def url_formulario(self) -> str:
        return f"{self.base_url}{FORM_PATH}"

    @property
    def url_validacion(self) -> str:
        return f"{self.base_url}{VALIDACION_PATH}"

    def leer_formulario(self) -> tuple[str, list[str]]:
        """GET al formulario: devuelve (_token, ambientes). Deja la cookie de sesion."""
        resp = self.session.get(self.url_formulario, timeout=TIMEOUT_GET)
        resp.raise_for_status()
        return extraer_token(resp.text), extraer_ambientes(resp.text)

    def publicar(self, ambiente: str, rama: str) -> dict:
        """Ejecuta el cambio de rama en el servidor. Requiere token+cookie frescos."""
        token, ambientes = self.leer_formulario()
        if ambiente not in ambientes:
            # Un ambiente fuera del select deja el request colgado >60s en el servidor.
            raise CyberPublishError(
                f"'{ambiente}' no esta en el select de {self.servidor}. Abortado antes "
                f"de postear (un ambiente inexistente cuelga el request)."
            )
        payload = {"_token": token, "ambiente": ambiente, "rama": rama}
        resp = self.session.post(
            self.url_validacion,
            files={k: (None, v) for k, v in payload.items()},  # el form es multipart
            headers={"Referer": self.url_formulario, "Origin": self.base_url},
            timeout=TIMEOUT_POST,
            allow_redirects=False,
        )
        consola = extraer_consola(resp.text) if resp.status_code == 200 else []
        if resp.status_code == 302:
            motivo = (
                "validacion_rechazada: el servidor redirigio al formulario sin ejecutar "
                "(rama vacia, <3 o >200 caracteres, o ambiente no seleccionado)."
            )
        elif resp.status_code != 200:
            motivo = f"http_{resp.status_code}"
        elif not consola:
            motivo = "respuesta_200_sin_consola: el servidor no devolvio salida de git."
        else:
            motivo = ""
        return {
            "servidor": self.servidor,
            "ambiente": ambiente,
            "rama": rama,
            "url": self.url_validacion,
            "http_status": resp.status_code,
            "ok": not motivo,
            "motivo": motivo,
            "consola": consola,
        }


def validar_rama(rama: str) -> None:
    if len(rama) < RAMA_MIN or len(rama) > RAMA_MAX:
        raise CyberPublishError(
            f"La rama '{rama}' tiene {len(rama)} caracteres; el servidor exige "
            f"entre {RAMA_MIN} y {RAMA_MAX}."
        )


def render_consola(resultado: dict) -> str:
    lineas = [
        f"servidor  : {resultado['servidor']}",
        f"ambiente  : {resultado['ambiente']}",
        f"rama      : {resultado['rama']}",
        f"http      : {resultado['http_status']}",
        f"resultado : {'OK' if resultado['ok'] else 'FALLO'}",
    ]
    if resultado["motivo"]:
        lineas.append(f"motivo    : {resultado['motivo']}")
    if resultado["consola"]:
        lineas.append("--- salida del servidor ---")
        lineas.extend(resultado["consola"])
    return "\n".join(lineas)
