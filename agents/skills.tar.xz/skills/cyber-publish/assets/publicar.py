#!/usr/bin/env python3
"""Publica la rama actual del repo en el ambiente dev/qa configurado del proyecto.

Por defecto NO ejecuta nada: imprime el plan (dry-run). Requiere `--apply` para
postear a `/ambiente/validacion`, que en el servidor descarta cambios locales y
hace checkout+pull de la rama en /internet/VDomain/<ambiente>.
"""
from __future__ import annotations

import argparse
import json
import sys

from webhook_api import (
    ConfigFaltante,
    CyberPublishError,
    WebhookClient,
    ambientes_de_servidor,
    entorno_config,
    rama_actual,
    rama_existe_en_origin,
    render_consola,
    validar_rama,
)

CODIGO_CONFIG_FALTANTE = 3
CODIGO_FALLO_REMOTO = 4


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    destino = parser.add_mutually_exclusive_group(required=True)
    destino.add_argument("--env", choices=("dev", "qa"), help="entorno de .cyber-publish.json")
    destino.add_argument("--ambiente", help="ambiente explicito; requiere --servidor")
    parser.add_argument("--servidor", help="tatenen | ptah (solo con --ambiente)")
    parser.add_argument("--proyecto", help="nombre del proyecto configurado en .cyber-publish.json")
    parser.add_argument("--rama", help="rama a publicar (default: rama actual del repo)")
    parser.add_argument("--apply", action="store_true", help="ejecuta de verdad el cambio")
    parser.add_argument(
        "--sin-check-origin",
        action="store_true",
        help="no verifica que la rama exista en origin (el servidor solo ve el repo central)",
    )
    parser.add_argument("--json", action="store_true", help="salida JSON")
    args = parser.parse_args()

    if args.ambiente and not args.servidor:
        raise CyberPublishError("--ambiente requiere --servidor")

    if args.env:
        entrada = entorno_config(args.env, proyecto=args.proyecto)
        servidor, ambiente = entrada["servidor"], entrada["ambiente"]
    else:
        servidor, ambiente = args.servidor, args.ambiente

    rama = args.rama or rama_actual()
    validar_rama(rama)

    if ambiente not in ambientes_de_servidor(servidor):
        raise CyberPublishError(
            f"'{ambiente}' no esta en el inventario de '{servidor}'. "
            f"Corre listar_ambientes.py o revisa .cyber-publish.json."
        )

    en_origin = None
    if not args.sin_check_origin:
        en_origin = rama_existe_en_origin(rama)
        if not en_origin:
            raise CyberPublishError(
                f"La rama '{rama}' no existe en origin. El servidor hace fetch del repo "
                f"central, asi que el checkout fallaria. Pushea primero o usa --sin-check-origin."
            )

    plan = {
        "entorno": args.env,
        "proyecto": args.proyecto,
        "servidor": servidor,
        "ambiente": ambiente,
        "rama": rama,
        "rama_en_origin": en_origin,
        "apply": bool(args.apply),
    }

    if not args.apply:
        plan["nota"] = "dry-run: no se envio nada. Agrega --apply para ejecutar."
        print(json.dumps(plan, ensure_ascii=False, indent=2) if args.json
              else "\n".join(f"{k:<15}: {v}" for k, v in plan.items()))
        return 0

    client = WebhookClient.desde_nombre(servidor)
    resultado = client.publicar(ambiente=ambiente, rama=rama)
    resultado["entorno"] = args.env

    print(json.dumps(resultado, ensure_ascii=False, indent=2) if args.json
          else render_consola(resultado))
    return 0 if resultado["ok"] else CODIGO_FALLO_REMOTO


if __name__ == "__main__":
    try:
        sys.exit(main())
    except ConfigFaltante as exc:
        print(f"{exc}", file=sys.stderr)
        print(
            "Pregunta al usuario los ambientes dev/qa (usa config_proyecto.py sugerir) "
            "y guardalos con config_proyecto.py set.",
            file=sys.stderr,
        )
        sys.exit(CODIGO_CONFIG_FALTANTE)
    except CyberPublishError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(1)
