---
name: cyber-publish
description: "Publicar/desplegar la rama actual del repo en los ambientes dev o qa de Cybercenter usando el formulario Ambiente/Rama de los servidores webhook (tatenen, ptah): listar ambientes disponibles, configurar que ambiente dev/qa tiene el proyecto y ejecutar el cambio de rama mostrando la salida de consola del servidor. Usar cuando se pida publicar, subir, desplegar, cambiar la rama de un ambiente, o saber en que ambiente esta un proyecto."
---

# cyber-publish

Los servidores webhook de Cybercenter exponen un formulario **Ambiente / Rama**
(`/ambiente/formulario`) que postea a `/ambiente/validacion`. Ese endpoint **no
previsualiza: ejecuta** — en el servidor hace `cd /internet/VDomain/<ambiente>`,
fetch del repo central, **descarta cambios locales**, checkout de la rama y pull.

Este skill automatiza ese formulario con `assets/*.py` (stdlib + `requests`).
Rutas relativas a la raíz del proyecto donde está instalado el skill
(`.agents/skills/cyber-publish/` vía symlink, o `agents/skills/cyber-publish/`
en el workspace de skills).

## Flujo

1. `listar_ambientes.py` — lee el select de **ambos** servidores y guarda el inventario en `assets/ambientes.json`.
2. `config_proyecto.py` — el workspace declara **sus proyectos** y sus ambientes dev/qa en `.cyber-publish.json` (raíz del workspace). Si falta el proyecto activo, **hay que preguntarle al usuario**.
3. `ramas.py` — lista ramas de GitLab o del `origin` local y resuelve el proyecto desde `.cyber-publish.json`.
4. `publicar.py` — publica la rama actual de git en el ambiente elegido y muestra la salida de consola del servidor.

## Servidores

| nombre | URL |
|---|---|
| `tatenen` | https://webhook.tatenen.cybercenter.cl |
| `ptah` | https://webhook.ptah.cybercenter.cl |

Están en `assets/servidores.json`; para agregar otro, edita ese archivo y re-lista.
**No hay login**: el formulario es público, solo requiere el `_token` CSRF y la
cookie de sesión del `GET` previo (el cliente lo hace solo).

## 1. Listar ambientes

```bash
cd agents/skills/cyber-publish/assets

# Refresca desde la red los dos servidores y guarda assets/ambientes.json
python3 listar_ambientes.py

# Solo un servidor (preserva en el JSON lo ya conocido del otro)
python3 listar_ambientes.py --servidor ptah

# Sin red, desde el cache, filtrando
python3 listar_ambientes.py --cache --filtro oit
```

Salida verificada de `--cache --filtro oit`:

```
== ptah (https://webhook.ptah.cybercenter.cl) — 2/43
  dcybercenter-oit.cc.cl
  tcybercenter-oit.cc.cl

== tatenen (https://webhook.tatenen.cybercenter.cl) — 2/39
  dcybercenter-oit.cc.cl
  tcybercenter-oit.cc.cl
```

Convención de nombres: prefijo **`d`** = desarrollo, **`t`** = QA/testing,
**`t2`**/`t...2` = segundo QA, sin prefijo = principal.

## 2. Configurar el proyecto (dev + qa)

La asociación proyecto → ambientes vive en **`.cyber-publish.json` en la raíz del
workspace** (commitéalo: es info de equipo, no hay secretos). El archivo puede
guardar varios proyectos:

```json
{
  "version": 2,
  "default_project": "cybercenter-oit",
  "proyectos": {
    "cybercenter-oit": {
      "ambientes": {
        "dev": {"servidor": "tatenen", "ambiente": "dcybercenter-oit.cc.cl"},
        "qa": {"servidor": "tatenen", "ambiente": "tcybercenter-oit.cc.cl"}
      },
      "gitlab": {"project_id": "75158951"}
    }
  }
}
```

Para que `ramas.py` use GitLab, el proyecto también necesita un `.env` con:

```dotenv
GITLAB_BASE_URL=https://gitlab.com
GITLAB_TOKEN=glpat_xxxxxxxxxxxxxxxxxxxx
```

Si falta el token, créalo en GitLab desde:
https://gitlab.com/-/user_settings/personal_access_tokens

```bash
# ¿Está configurado? Sale con exit 3 si falta.
python3 .agents/skills/cyber-publish/assets/config_proyecto.py show

# Mostrar un proyecto específico
python3 .agents/skills/cyber-publish/assets/config_proyecto.py show --proyecto cybercenter-oit

# Mostrar la config normalizada en JSON
python3 .agents/skills/cyber-publish/assets/config_proyecto.py show --json --proyecto cybercenter-oit

# Candidatos cruzando el nombre del repo con el inventario
python3 .agents/skills/cyber-publish/assets/config_proyecto.py sugerir

# Guardar solo el ID de GitLab del proyecto activo
python3 .agents/skills/cyber-publish/assets/config_proyecto.py set \
  --proyecto cybercenter-oit \
  --gitlab-project-id 75158951

# Guardar la elección del usuario (formato servidor:ambiente)
python3 .agents/skills/cyber-publish/assets/config_proyecto.py set \
  --proyecto cybercenter-oit \
  --dev tatenen:dcybercenter-oit.cc.cl \
  --qa  tatenen:tcybercenter-oit.cc.cl \
  --gitlab-project-id 75158951
```

**Si `show` sale con exit 3 (`CONFIG_FALTANTE`), el agente NO debe adivinar:**
corre `sugerir`, muéstrale los candidatos al usuario, pregúntale qué proyecto
configurar, cuál es dev y cuál es qa (**incluido el servidor** — el mismo
nombre de ambiente existe en tatenen y en ptah) y recién entonces corre `set`.

**Si `ramas.py` no puede usar GitLab**, verifica que el proyecto tenga
`gitlab.project_id` en `.cyber-publish.json` y que el `.env` del workspace tenga
`GITLAB_BASE_URL` y `GITLAB_TOKEN`. Si no tienes token, usa el enlace de GitLab
de arriba y pide un acceso con permisos de lectura de API.

`show` verificado:

```
config    : /ruta/al/proyecto/.cyber-publish.json
proyecto  : cybercenter-oit
dev       : dcybercenter-oit.cc.cl  @tatenen
qa        : tcybercenter-oit.cc.cl  @tatenen
```

## 3. Publicar (driver principal)

`publicar.py` es **dry-run por defecto**; sin `--apply` no toca el servidor.

```bash
# Plan: qué se publicaría (rama actual del repo) en qa. Verifica que la rama esté en origin.
python3 .agents/skills/cyber-publish/assets/publicar.py --env qa --proyecto cybercenter-oit

# Ejecutar de verdad en qa con la rama actual
# (--sin-check-origin solo si el remote local no es el repo central que ve el servidor)
python3 .agents/skills/cyber-publish/assets/publicar.py --env qa --proyecto cybercenter-oit --apply --sin-check-origin

# Ambiente explícito, sin usar .cyber-publish.json, rama y salida JSON
python3 .agents/skills/cyber-publish/assets/publicar.py \
  --servidor tatenen --ambiente tcybercenter-oit.cc.cl \
  --rama 15-oit-cambio-de-obligatoriedad --sin-check-origin --apply --json

# Listar ramas de un proyecto concreto en GitLab
python3 .agents/skills/cyber-publish/assets/ramas.py --fuente gitlab --proyecto cybercenter-oit --limite 10
```

Salida verificada de un `--apply` real:

```
servidor  : tatenen
ambiente  : tcybercenter-oit.cc.cl
rama      : 15-oit-cambio-de-obligatoriedad
http      : 200
resultado : OK
--- salida del servidor ---
>>>> Cambiando al directorio del proyecto: /internet/VDomain/tcybercenter-oit.cc.cl
>>>> Obteniendo todas las novedades desde el repositorio central
>>>> Ignorando / deshaciendo cualquier cambio local que puediese existir
>>>> Cambiando a la rama solicitada: 15-oit-cambio-de-obligatoriedad
Your branch is up to date with 'origin/15-oit-cambio-de-obligatoriedad'.
>>>> Bajando los cambios
Already up to date.
>>>> Proceso finalizado
```

Flags: `--env dev|qa` (desde config, con `--proyecto` si hay varios) **o**
`--servidor` + `--ambiente`; `--proyecto`; `--rama` (default: rama actual, vía
`git symbolic-ref`); `--apply`;
`--sin-check-origin`; `--json`.

`ramas.py` flags: `--fuente auto|gitlab|git`; `--proyecto`; `--project-id`
(override manual); `--filtro`; `--limite`; `--json`.

Exit codes: `0` ok · `1` error de uso/validación local · `3` `CONFIG_FALTANTE`
(preguntar al usuario) · `4` el servidor respondió pero el cambio falló.

## Chequeos previos que hace el driver (y por qué)

- **Ambiente contra el inventario.** Un `ambiente` que no está en el select
  **cuelga el request >60 s** en el servidor (probado con `no-existe-xyz.cc.cl`:
  timeout a los 60 s sin respuesta). El driver aborta antes de postear.
- **Rama en `origin`** (`git ls-remote --heads origin <rama>`). El servidor hace
  fetch del **repo central**, no de tu working copy: una rama solo local haría
  fallar el checkout. Sáltalo con `--sin-check-origin` si el remote no es el que
  ve el servidor.
- **Largo de la rama 3–200.** Es la regla Laravel del form; fuera de rango el
  servidor responde `302` de vuelta al formulario **sin ejecutar nada y sin
  mensaje de error legible**.

## Gotchas

- **`/ambiente/validacion` no valida, despliega.** El nombre engaña. No existe
  paso de confirmación: un solo POST y el ambiente queda en la rama nueva.
- **`>>>> Ignorando / deshaciendo cualquier cambio local`**: cualquier hotfix
  editado a mano en el servidor se pierde. Avisa antes de publicar.
- **El mismo nombre de ambiente existe en los dos servidores.**
  `dcybercenter-oit.cc.cl` y `tcybercenter-oit.cc.cl` están en tatenen **y** en
  ptah, apuntando a máquinas distintas. Por eso la config guarda
  `{servidor, ambiente}` y no solo el dominio; `sugerir` los devuelve empatados
  con el mismo score a propósito.
- **El token es por sesión.** Hay que hacer `GET /ambiente/formulario` y postear
  con esa misma cookie; reusar un `_token` viejo da 419. El cliente refresca el
  token en cada `publicar()`.
- **`--apply` es idempotente pero no gratis.** Si la rama ya está aplicada
  imprime `Already up to date.`; igual descarta cambios locales del servidor.
- **El POST tarda lo que tarde `git pull`** (~5 s en la prueba). Timeout de
  lectura: 240 s.
- **Errores del form no se renderizan.** Un `302` vuelve al formulario sin
  `invalid-feedback` en el HTML: no hay detalle del motivo. Por eso las
  validaciones se hacen del lado del cliente.
- **La raíz del servidor es la welcome page de Laravel** y no hay índice de
  rutas: `/ambiente/formulario` es la única página útil (`/ambiente`, `/home`,
  `/dashboard` dan 404).
- **El formulario es público, sin autenticación**, y expone el inventario
  completo de ambientes de clientes. Trátalo como superficie sensible.

## Troubleshooting

| Síntoma | Causa / arreglo |
|---|---|
| `ERROR: No existe .../ambientes.json` | Falta el inventario: `python3 listar_ambientes.py` |
| `CONFIG_FALTANTE` + exit 3 | El proyecto no declaró dev/qa: `sugerir` → preguntar al usuario → `set` |
| `ERROR: 'x.cc.cl' no existe en tatenen. Parecidos: ...` | Typo en el dominio (ej. `.cl` en vez de `.cc.cl`); usa el sugerido |
| `ERROR: La rama 'x' no existe en origin` | Falta `git push -u origin <rama>`, o el remote local no es el central → `--sin-check-origin` |
| `ERROR: No hay rama actual (HEAD detached...)` | Repo en detached HEAD o sin commits: pasa `--rama <nombre>` |
| `gitlab no disponible (...) -> fallback a origin` | Falta `GITLAB_TOKEN`/`GITLAB_BASE_URL` o `gitlab.project_id`; crea el token en https://gitlab.com/-/user_settings/personal_access_tokens |
| `resultado : FALLO` + `motivo: validacion_rechazada` (http 302) | El server rechazó rama/ambiente sin ejecutar; revisa largo de rama y que el ambiente esté en el select |
| El comando se cuelga ~4 min y muere | Estás posteando un ambiente inexistente salteando el guard, o `git pull` colgado en el servidor |

Anatomía del formulario y del endpoint: `references/formulario.md`.
