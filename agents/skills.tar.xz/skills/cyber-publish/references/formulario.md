# Anatomía del formulario Ambiente / Rama

Relevado el 2026-07-31 contra `webhook.tatenen.cybercenter.cl` y
`webhook.ptah.cybercenter.cl` (HTML crudo, no render).

## Stack

Laravel + Blade, Bootstrap 5.0.2, Select2 4.1.0-rc.0, jQuery 3.7.1,
`jquery-validate` 1.20.0 y `proengsoft/laravel-jsvalidation`
(`/vendor/jsvalidation/js/jsvalidation.min.js`). Sin autenticación.

## `GET /ambiente/formulario`

```html
<form id="ambienteForm" method="POST"
      action="https://webhook.<host>.cybercenter.cl/ambiente/validacion"
      novalidate enctype="multipart/form-data">
  <input type="hidden" name="_token" value="<csrf>" autocomplete="off">
  <select class="form-select select2" name="ambiente" id="ambiente">
    <option value=""></option>
    <option value="dcybercenter-oit.cc.cl">dcybercenter-oit.cc.cl</option>
    ...
  </select>
  <input class="form-control" type="text" name="rama" id="rama" value="" />
  <button type="submit" class="btn btn-primary">Aplicar</button>
</form>
```

Reglas emitidas por `laravel-jsvalidation` en el `<script>` final:

- `ambiente`: `Required` — "Debe seleccionar el ambiente con el que desea operar."
- `rama`: `Required` ("Debe indicar que rama desea configurar."), `String`,
  `Min:3`, `Max:200`.

Notas:

- `<title>Ambiente / Rama</title>`, `<h1>Configuración de ambientes</h1>`,
  `<h2>Servidor: webhook.<host>.cybercenter.cl</h2>`.
- El `select` **no** trae opción preseleccionada y `rama` viene vacío: la página
  no muestra en qué rama está hoy cada ambiente.
- La raíz del host (`/`) es la welcome page por defecto de Laravel. `/ambiente`,
  `/home`, `/dashboard`, `/menu` → 404.

## `POST /ambiente/validacion`

Campos: `_token`, `ambiente`, `rama`. `multipart/form-data` (también acepta
urlencoded). Requiere la cookie de sesión del `GET` anterior junto al `_token`.

**Ejecuta inmediatamente** — no es preview ni tiene paso de confirmación. Lo que
reporta la salida, en orden:

1. `>>>> Cambiando al directorio del proyecto: /internet/VDomain/<ambiente>`
2. `>>>> Obteniendo todas las novedades desde el repositorio central` (fetch)
3. `>>>> Ignorando / deshaciendo cualquier cambio local que puediese existir`
4. `>>>> Cambiando a la rama solicitada: <rama>` (checkout)
5. `>>>> Bajando los cambios` (pull)
6. `>>>> Proceso finalizado`

### Respuestas observadas

| Caso | Resultado |
|---|---|
| ambiente del select + rama existente en origin | `200`, salida en `<pre><code class="language-bash">` con líneas separadas por `<br>`, y un `<a>Volver</a>` al formulario |
| `rama=""` | `302 → /ambiente/formulario`, no ejecuta; el `GET` siguiente **no** renderiza mensajes de error |
| `ambiente` fuera del select (`no-existe-xyz.cc.cl`) | **request colgado**: timeout a los 60 s sin respuesta |

### Parseo del resultado

```python
bloque = re.search(r"<pre[^>]*>(.*?)</pre>", html_text, flags=re.S)
cuerpo = re.sub(r"</?code[^>]*>", "", bloque.group(1))
lineas = [html.unescape(re.sub(r"<[^>]+>", "", x)).strip()
          for x in re.split(r"<br\s*/?>", cuerpo)]
```

## Inventario relevado

- `tatenen`: 39 ambientes — arauco, abertis (autopista-del-sol), avo,
  cybercenter (clan-digital, sitio-web, oit), enap, fundacion-avanzar, imperial,
  minsal (siac-oirs, salud-mental), sernatur, transbank, bioelements, mascotas.
- `ptah`: 43 ambientes — abertis (autopase, tac), cybercenter (oit, sitio-web),
  huechuraba, imperial (b2b, connector, sitio-web, centro-experiencia, tienda),
  juegospanam, las-condes, licitaciones, minsal (sidot, yodonovida), sernatur
  antofagasta, sodexo (junaeb, misodexo, crece).

Cachéado en `assets/ambientes.json` con `total`, `base_url` y URLs de cada
servidor. `dcybercenter-oit.cc.cl` / `tcybercenter-oit.cc.cl` aparecen en
**ambos** servidores — el nombre de ambiente no es identificador único.
