#!/usr/bin/env python3
import argparse
import csv
import json
import re
import sys
from pathlib import Path


RUT_RE = re.compile(r"\b\d{1,2}(?:\.\d{3}){2}-[\dkK]\b|\b\d{7,8}-[\dkK]\b")
DATE_RE = re.compile(r"^\d{1,2}[./-]\d{1,2}[./-]\d{2,4}$")


def clean_text(value: str) -> str:
    return " ".join((value or "").split()).strip()


def load_gitlab_client(project_root: Path):
    gitlab_api_dir = project_root / ".agents" / "skills" / "gitlab-connect" / "assets"
    if str(gitlab_api_dir) not in sys.path:
        sys.path.insert(0, str(gitlab_api_dir))
    from api import GitLabClient  # noqa: E402

    return GitLabClient


def load_json(path: Path) -> dict:
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, payload: dict) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def fetch_all_issues(client, project_id: str) -> list[dict]:
    issues: list[dict] = []
    page = 1
    while True:
        batch = client.get(
            f"/projects/{project_id}/issues",
            query={
                "state": "all",
                "per_page": 100,
                "order_by": "created_at",
                "sort": "asc",
                "page": page,
            },
        )
        if not batch:
            break
        issues.extend(batch)
        if len(batch) < 100:
            break
        page += 1
    return issues


def is_name_candidate(line: str) -> bool:
    candidate = clean_text(line)
    if not candidate:
        return False
    if len(candidate) < 5 or "@" in candidate:
        return False
    if any(token.lower() in {"estimados", "estimado", "saludos", "atentos", "gracias", "buenos", "buenas"} for token in candidate.split()):
        return False
    if len(candidate.split()) < 2:
        return False
    if DATE_RE.match(candidate):
        return False
    if candidate.upper() == candidate and len(candidate.split()) == 1:
        return False
    if len(candidate.split()) > 6:
        return False
    if ":" in candidate or "," in candidate:
        return False
    return any(ch.isalpha() for ch in candidate)


def extract_name(description: str) -> str:
    text = description or ""
    explicit_patterns = [
        r"Nombre completo:\s*([^\n\r]+)",
        r"Nombre:\s*([^\n\r]+)",
        r"Solicitante:\s*([^\n\r]+)",
        r"De:\s*\"?([^\"<\n\r]+)\"?\s*<",
    ]
    for pattern in explicit_patterns:
        match = re.search(pattern, text, flags=re.I)
        if match:
            candidate = clean_text(match.group(1))
            if is_name_candidate(candidate):
                return candidate

    lines = [clean_text(line) for line in text.splitlines()]
    for index, line in enumerate(lines):
        if not RUT_RE.search(line):
            continue

        before = clean_text(RUT_RE.split(line, maxsplit=1)[0].replace("Rut", "").replace("RUT", ""))
        if is_name_candidate(before):
            return before

        for previous in range(index - 1, -1, -1):
            if not lines[previous]:
                continue
            if is_name_candidate(lines[previous]):
                return lines[previous]
            break

    return ""


def extract_rut(description: str) -> str:
    match = RUT_RE.search(description or "")
    return clean_text(match.group(0)) if match else ""


def extract_institution(description: str) -> str:
    lines = [clean_text(line) for line in (description or "").splitlines()]
    for index, line in enumerate(lines):
        if not RUT_RE.search(line):
            continue
        for candidate in lines[index + 1 : index + 4]:
            if (
                candidate
                and "@" not in candidate
                and not candidate.lower().startswith(("saludos", "gracias", "atent", "sin otro"))
                and not DATE_RE.match(candidate)
            ):
                if not RUT_RE.search(candidate):
                    return candidate.rstrip(".")
    return ""


def derive_status(issue_state: str) -> str:
    return "Cerrado" if issue_state == "closed" else "pendiente"


def build_ticket_payload(project_id: str, issue: dict, existing: dict) -> dict:
    description = issue.get("description") or ""
    payload = dict(existing)
    payload.setdefault("gitlab_project_id", project_id)
    payload["issue_iid"] = str(issue.get("iid") or "")
    payload["issue_title"] = issue.get("title") or ""
    payload["issue_url"] = issue.get("web_url") or ""
    payload["title"] = issue.get("title") or payload.get("title") or ""
    payload["url"] = issue.get("web_url") or payload.get("url") or ""
    payload["gitlab_state"] = issue.get("state") or ""
    payload["issue_state"] = issue.get("state") or ""
    payload["gitlab_labels"] = issue.get("labels", [])
    payload["labels"] = payload.get("labels", issue.get("labels", []))
    payload["issue_created_at"] = issue.get("created_at") or payload.get("issue_created_at") or payload.get("updated_at") or ""
    payload["updated_at"] = issue.get("updated_at") or payload.get("updated_at") or ""
    payload["status"] = payload.get("status") or derive_status(issue.get("state") or "")
    payload["author"] = payload.get("author") or {
        "name": (issue.get("author") or {}).get("name", ""),
        "username": (issue.get("author") or {}).get("username", ""),
    }
    payload["service_desk_reply_to"] = issue.get("service_desk_reply_to") or payload.get("service_desk_reply_to") or ""
    payload["solicitante"] = payload.get("solicitante") or {
        "nombre_completo": extract_name(description),
        "rut": extract_rut(description),
        "institucion": extract_institution(description),
        "fecha_nacimiento": "",
    }
    payload["json_file_name"] = f"ticket_{payload['issue_iid']}.json"
    payload.setdefault("validaciones", {})
    payload["validaciones"].setdefault("gitlab_issue_read", True)
    payload["validaciones"].setdefault("service_desk_reply_to_obtenido", bool(payload["service_desk_reply_to"]))
    payload.setdefault("observaciones", [])
    if not existing:
        payload["observaciones"] = [
            "Sin enriquecimiento SIDOT en esta sincronización local desde GitLab.",
        ]
    return payload


def index_name_from_ticket(ticket: dict, issue: dict) -> str:
    solicitante = ticket.get("solicitante") or {}
    for key in ("nombre_completo", "name", "full_name"):
        value = clean_text(solicitante.get(key, ""))
        if value:
            return value
    for key in ("solicitante_nombre",):
        value = clean_text(ticket.get(key, ""))
        if value:
            return value
    description = issue.get("description") or ""
    extracted = extract_name(description)
    return extracted


def client_get_project_id(project_root: Path) -> str:
    env_path = project_root / ".env"
    env_values = {}
    if env_path.exists():
        for raw_line in env_path.read_text(encoding="utf-8").splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            env_values[key.strip()] = value.strip().strip('"').strip("'")
    project_id = env_values.get("GITLAB_PROJECT_ID", "").strip()
    if not project_id:
        raise RuntimeError(f"Missing required variable GITLAB_PROJECT_ID in {env_path}")
    return project_id


def main() -> None:
    parser = argparse.ArgumentParser(description="Sync SIDOT GitLab tickets into doc/.sidot/git-tickets")
    parser.add_argument("--project-root", default=str(Path.cwd().resolve()), help="Project root path")
    args = parser.parse_args()

    project_root = Path(args.project_root).resolve()
    tickets_dir = project_root / "doc" / ".sidot" / "git-tickets"
    tickets_dir.mkdir(parents=True, exist_ok=True)

    GitLabClient = load_gitlab_client(project_root)
    client = GitLabClient.from_project_root(project_root)
    project_id = client_get_project_id(project_root)
    remote_issues = fetch_all_issues(client, project_id)
    remote_by_iid = {str(issue["iid"]): issue for issue in remote_issues}

    created = 0
    preserved = 0
    missing_local = []
    rows = []
    sync_marker = "Sin enriquecimiento SIDOT en esta sincronización local desde GitLab."

    for issue in remote_issues:
        iid = str(issue["iid"])
        ticket_path = tickets_dir / f"ticket_{iid}.json"
        existing = load_json(ticket_path)
        should_refresh = not existing or sync_marker in (existing.get("observaciones") or [])
        if existing and not should_refresh:
            preserved += 1
        else:
            created += 1
            missing_local.append(iid)
        payload = build_ticket_payload(project_id, issue, {} if should_refresh else existing)
        if should_refresh:
            write_json(ticket_path, payload)
        row_name = index_name_from_ticket(payload, issue)
        rows.append(
            {
                "id": iid,
                "fecha": payload.get("issue_created_at") or payload.get("updated_at") or issue.get("created_at") or "",
                "estado": payload.get("status") or derive_status(issue.get("state") or ""),
                "nombre solicitante": row_name,
                "json file name": f"ticket_{iid}.json",
            }
        )

    rows.sort(key=lambda row: row["fecha"])
    index_path = tickets_dir / "index.csv"
    with index_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["id", "fecha", "estado", "nombre solicitante", "json file name"])
        writer.writeheader()
        writer.writerows(rows)

    orphaned = sorted(
        int(path.stem.split("_", 1)[1])
        for path in tickets_dir.glob("ticket_*.json")
        if path.stem.split("_", 1)[1].isdigit() and path.stem.split("_", 1)[1] not in remote_by_iid
    )

    print(json.dumps(
        {
            "remote_issues": len(remote_issues),
            "created": created,
            "preserved": preserved,
            "index_rows": len(rows),
            "orphaned_local_ticket_iids": orphaned,
            "missing_local_ticket_iids": missing_local,
            "index_path": str(index_path),
        },
        ensure_ascii=False,
        indent=2,
    ))


if __name__ == "__main__":
    main()
