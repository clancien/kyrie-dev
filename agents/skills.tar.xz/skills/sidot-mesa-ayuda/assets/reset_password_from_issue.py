#!/usr/bin/env python3
import argparse
import csv
import json
import re
import secrets
import string
import sys
import importlib.util
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote, urljoin

from bs4 import BeautifulSoup

MONTH_NAMES_ES = {
    1: "Enero",
    2: "Febrero",
    3: "Marzo",
    4: "Abril",
    5: "Mayo",
    6: "Junio",
    7: "Julio",
    8: "Agosto",
    9: "Septiembre",
    10: "Octubre",
    11: "Noviembre",
    12: "Diciembre",
}


def load_module(module_name: str, path: Path):
    spec = importlib.util.spec_from_file_location(module_name, str(path))
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load module: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def load_env_file(env_path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not env_path.exists():
        return values
    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip().strip('"').strip("'")
    return values


def env_get(key: str, env_values: dict[str, str], env_path: Path, required: bool = True) -> str:
    value = env_values.get(key, "").strip()
    if required and not value:
        raise RuntimeError(f"Missing required variable {key} in {env_path}")
    return value


def generate_password(length: int = 20) -> str:
    alphabet = string.ascii_letters + string.digits + "!@#$%^&*()-_=+[]{}"
    return "".join(secrets.choice(alphabet) for _ in range(length))


def require_confirmation(title: str, details: list[str]) -> None:
    print("\n=== CONFIRMACION REQUERIDA ===")
    print(title)
    for item in details:
        print(f"- {item}")
    answer = input("Escriba 'SI' para confirmar: ").strip().upper()
    if answer != "SI":
        raise RuntimeError("Operacion cancelada por el usuario.")


def _looks_like_email_or_login(value: str) -> bool:
    candidate = (value or "").strip()
    if not candidate:
        return True
    if "@" in candidate:
        return True
    return bool(re.fullmatch(r"[A-Za-z0-9._-]+", candidate))


def parse_full_name_from_signature(description: str) -> str | None:
    if not description:
        return None

    # Common Service Desk signature markers (keeps change local and predictable).
    signature_patterns = [
        r"\*\s*F\*\*rancesca\s+Gajardo\s+Zurita\s*\*",
        r"\*\s*([A-ZÁÉÍÓÚÑ][A-Za-zÁÉÍÓÚÑáéíóúñ]+(?:\s+[A-ZÁÉÍÓÚÑ][A-Za-zÁÉÍÓÚÑáéíóúñ]+){1,3})\s*\*",
    ]
    for pattern in signature_patterns:
        match = re.search(pattern, description, flags=re.I)
        if not match:
            continue
        raw = match.group(1) if match.lastindex else match.group(0)
        cleaned = " ".join(raw.replace("*", "").split())
        if cleaned:
            return cleaned

    # Fallback: line right before a RUT line.
    lines = [line.strip() for line in (description or "").splitlines()]
    for idx, line in enumerate(lines):
        if not re.fullmatch(r"\d{7,8}-[\dkK]", line):
            continue
        if idx == 0:
            continue
        prev = lines[idx - 1].strip(" :.-")
        if re.fullmatch(r"[A-ZÁÉÍÓÚÑ][A-Za-zÁÉÍÓÚÑáéíóúñ]+(?:\s+[A-ZÁÉÍÓÚÑ][A-Za-zÁÉÍÓÚÑáéíóúñ]+){1,3}", prev):
            return " ".join(prev.split())

    return None


def parse_name_for_unique_edit_link(html_text: str, edit_link: str) -> str | None:
    soup = BeautifulSoup(html_text, "html.parser")
    anchor = soup.find("a", href=edit_link)
    if anchor is None:
        return None
    row = anchor.find_parent("tr")
    if row is None:
        return None
    columns = row.find_all("td")
    if len(columns) < 2:
        return None
    name = " ".join(columns[1].get_text(" ", strip=True).split())
    return name or None


def resolve_applicant_name(args_name: str, description: str, sidot_user_query: str, sidot_search_html: str, unique_edit_link: str) -> str:
    explicit = " ".join((args_name or "").split())
    if explicit:
        return explicit

    for candidate in (
        parse_issue_full_name(description),
        parse_full_name_from_signature(description),
        parse_name_for_unique_edit_link(sidot_search_html, unique_edit_link),
    ):
        cleaned = " ".join((candidate or "").split())
        if cleaned and not _looks_like_email_or_login(cleaned):
            return cleaned

    if _looks_like_email_or_login(sidot_user_query):
        raise RuntimeError(
            "Could not derive applicant full name safely. Pass --solicitante-nombre to avoid greeting with email/login."
        )

    return sidot_user_query


def parse_issue_username(description: str) -> str | None:
    for pattern in [r"Usuario:\s*([A-Za-z0-9._-]+)", r"usuario\s*sidot\s*:\s*([A-Za-z0-9._-]+)", r"login:\s*([A-Za-z0-9._-]+)"]:
        m = re.search(pattern, description or "", flags=re.I)
        if m:
            return m.group(1).strip()
    return None


def parse_issue_service_desk_email(issue_data: dict) -> str | None:
    email = (issue_data.get("service_desk_reply_to") or "").strip().rstrip(".,;")
    return email or None


def parse_issue_full_name(description: str) -> str | None:
    for pattern in [r"Nombre:\s*([^\n\r]+)", r"Nombre completo:\s*([^\n\r]+)", r"Solicitante:\s*([^\n\r]+)"]:
        m = re.search(pattern, description or "", flags=re.I)
        if m:
            name = " ".join(m.group(1).strip().rstrip(".").split())
            if name:
                return name
    return None


def infer_gender_from_name(full_name: str) -> str | None:
    first = (full_name.strip().split()[0] if full_name else "").lower()
    female_names = {"maria", "claudia", "paula", "carolina", "sofia", "camila", "valentina", "daniela", "andrea", "patricia", "gabriela", "fernanda"}
    male_names = {"juan", "carlos", "jaime", "pedro", "jose", "miguel", "cristian", "sebastian", "rodrigo", "ricardo", "manuel", "francisco"}
    if first in female_names:
        return "F"
    if first in male_names:
        return "M"
    if first.endswith("a"):
        return "F"
    if first.endswith(("o", "n", "r", "l", "s")):
        return "M"
    return None


def build_saludo(nombre: str, sexo: str | None) -> str:
    cleaned = " ".join((nombre or "").split())
    if not cleaned:
        raise RuntimeError("Missing applicant name for personalized greeting.")
    normalized = (sexo or "").strip().upper()
    if normalized not in {"F", "M"}:
        normalized = infer_gender_from_name(cleaned) or ""
        if normalized not in {"F", "M"}:
            raise RuntimeError("Could not infer applicant gender. Use --sexo F or --sexo M.")
    return f"{'Estimada' if normalized == 'F' else 'Estimado'} {cleaned}"


def parse_user_edit_link(html_text: str) -> str | None:
    m = re.search(r'href="(/pref/usuario/edit/\d+\?state=[^"]+)"', html_text, flags=re.I)
    return m.group(1) if m else None


def parse_user_edit_links(html_text: str) -> list[str]:
    links: list[str] = []
    for match in re.finditer(r'href="(/pref/usuario/edit/\d+\?state=[^"]+)"', html_text, flags=re.I):
        link = match.group(1)
        if link not in links:
            links.append(link)
    return links


def collect_multiple_select_values(form: BeautifulSoup, name: str, hidden_name: str) -> list[str]:
    select = form.find(attrs={"name": name})
    values = []
    if select is not None:
        values = [option.get("value", "") for option in select.find_all("option", selected=True)]

    if values:
        return values

    hidden = form.find(attrs={"name": hidden_name})
    raw_values = hidden.get("data-values", "") if hidden is not None else ""
    return re.findall(r"\d+", raw_values)


def collect_password_reset_payload(form: BeautifulSoup, new_password: str) -> list[tuple[str, str]]:
    required_fields = ["__csrftoken", "usuarioId", "state"]
    payload: list[tuple[str, str]] = []
    for field in required_fields:
        element = form.find(attrs={"name": field})
        if element is None:
            raise RuntimeError(f"Could not find expected SIDOT reset field: {field}")
        payload.append((field, element.get("value", "")))

    payload.append(("contrasenaNew", new_password))
    payload.append(("contrasenaRepeat", new_password))
    for value in collect_multiple_select_values(
        form,
        "hospitalesProcuramientoIds",
        "struts.hiddenHospitalesProcuramientoIds",
    ):
        payload.append(("hospitalesProcuramientoIds", value))
    for value in collect_multiple_select_values(
        form,
        "hospitalesTrasplantesIds",
        "struts.hiddenHospitalesTrasplantesIds",
    ):
        payload.append(("hospitalesTrasplantesIds", value))
    return payload


def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def build_monthly_milestone_title(issue_created_at: str) -> str:
    raw = (issue_created_at or "").strip()
    if not raw:
        raise RuntimeError("Missing issue_created_at for milestone derivation.")
    normalized = raw.replace("Z", "+00:00")
    created_at = datetime.fromisoformat(normalized)
    month_name = MONTH_NAMES_ES.get(created_at.month)
    if not month_name:
        raise RuntimeError(f"Unsupported month value for milestone derivation: {created_at.month}")
    return f"Mantenciones {month_name} {created_at.year}"


def tickets_dir(project_root: Path) -> Path:
    return project_root / "doc" / ".sidot" / "git-tickets"


def ticket_json_path(project_root: Path, issue_iid: str) -> Path:
    return tickets_dir(project_root) / f"ticket_{issue_iid}.json"


def ticket_index_csv_path(project_root: Path) -> Path:
    return tickets_dir(project_root) / "index.csv"


def ensure_ticket_store(project_root: Path) -> None:
    tickets_dir(project_root).mkdir(parents=True, exist_ok=True)


def load_ticket(project_root: Path, issue_iid: str) -> dict:
    path = ticket_json_path(project_root, issue_iid)
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def write_ticket(project_root: Path, issue_iid: str, ticket_data: dict) -> Path:
    ensure_ticket_store(project_root)
    path = ticket_json_path(project_root, issue_iid)
    normalized = dict(ticket_data)
    normalized.setdefault("issue_iid", str(issue_iid))
    normalized["json_file_name"] = path.name
    normalized["updated_at"] = now_iso()
    path.write_text(json.dumps(normalized, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    rebuild_ticket_index(project_root)
    return path


def merge_and_write_ticket(project_root: Path, issue_iid: str, updates: dict) -> Path:
    current = load_ticket(project_root, issue_iid)
    current.update(updates)
    return write_ticket(project_root, issue_iid, current)


def ticket_sort_key(path: Path) -> tuple[int, str]:
    match = re.search(r"ticket_(\d+)\.json$", path.name)
    return (int(match.group(1)) if match else 0, path.name)


def ticket_state_for_index(ticket_data: dict) -> str:
    workflow_status = (ticket_data.get("workflow_status") or "").strip()
    if workflow_status:
        return workflow_status
    status = (ticket_data.get("status") or "").strip()
    if status:
        return status
    labels = ticket_data.get("labels") or []
    for label in labels:
        if isinstance(label, str) and label.lower().startswith("estado:"):
            return label.split(":", 1)[1].strip()
    issue_state = (ticket_data.get("issue_state") or "").strip()
    if issue_state:
        return issue_state
    gitlab_state = (ticket_data.get("gitlab_state") or "").strip()
    if gitlab_state:
        mapping = {
            "closed": "Cerrado",
            "opened": "Abierto",
            "reopened": "Reabierto",
        }
        return mapping.get(gitlab_state.lower(), gitlab_state)
    return ""


def ticket_name_for_index(ticket_data: dict) -> str:
    applicant = ticket_data.get("applicant") or {}
    solicitante = ticket_data.get("solicitante") or {}
    author = ticket_data.get("author") or {}
    for value in (
        applicant.get("full_name"),
        applicant.get("name"),
        solicitante.get("nombre_completo"),
        solicitante.get("nombre"),
        ticket_data.get("solicitante_nombre"),
        ticket_data.get("full_name"),
        ticket_data.get("nombre_completo"),
        author.get("name") if isinstance(author, dict) else "",
        author.get("username") if isinstance(author, dict) else "",
    ):
        text = str(value or "").strip()
        if text:
            return text
    return ""


def ticket_date_for_index(ticket_data: dict) -> str:
    for key in ("issue_created_at", "updated_at", "created_at"):
        value = str(ticket_data.get(key) or "").strip()
        if value:
            return value
    return ""


def rebuild_ticket_index(project_root: Path) -> Path:
    ensure_ticket_store(project_root)
    csv_path = ticket_index_csv_path(project_root)
    rows: list[dict[str, str]] = []
    for json_path in sorted(tickets_dir(project_root).glob("ticket_*.json"), key=ticket_sort_key):
        ticket_data = json.loads(json_path.read_text(encoding="utf-8"))
        applicant = ticket_data.get("applicant") or {}
        rows.append(
            {
                "id": str(ticket_data.get("issue_iid") or ""),
                "fecha": ticket_date_for_index(ticket_data),
                "estado": ticket_state_for_index(ticket_data),
                "nombre solicitante": ticket_name_for_index(ticket_data),
                "json file name": json_path.name,
            }
        )

    with csv_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["id", "fecha", "estado", "nombre solicitante", "json file name"])
        writer.writeheader()
        writer.writerows(rows)
    return csv_path


def require_milestone_confirmation(project_id: str, issue_iid: str, milestone_title: str, existing: bool) -> None:
    require_confirmation(
        "Modificar GitLab: crear o reutilizar milestone mensual.",
        [
            f"Proyecto: {project_id}",
            f"Issue IID: {issue_iid}",
            f"Milestone: {milestone_title}",
            "Accion: crear milestone" if not existing else "Accion: reutilizar milestone existente",
            "Accion final: asignar milestone al issue al cerrar",
        ],
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="SIDOT Mesa Ayuda: reset password from a GitLab issue and close it.")
    parser.add_argument("--project-root", default=str(Path.cwd().resolve()))
    parser.add_argument("--issue-iid", required=True)
    parser.add_argument("--solicitante-nombre", default="")
    parser.add_argument("--sexo", default="")
    parser.add_argument("--sidot-user-query", default="")
    parser.add_argument("--sidot-login", default="", help="SIDOT login to verify after resetting the password.")
    parser.add_argument("--skip-start-note", action="store_true")
    parser.add_argument("--skip-close", action="store_true")
    args = parser.parse_args()

    project_root = Path(args.project_root).resolve()
    env_path = project_root / ".env"
    env_values = load_env_file(env_path)
    gitlab_api = load_module("gitlab_api", project_root / ".agents/skills/gitlab-connect/assets/api.py")
    sidot_api = load_module("sidot_api", project_root / ".agents/skills/sidot-connect/assets/api.py")
    GitLabClient = gitlab_api.GitLabClient
    SidotClient = sidot_api.SidotClient
    gitlab = GitLabClient.from_project_root(project_root)
    sidot = SidotClient.from_project_root(project_root)
    sidot.login()

    env_project = env_get("GITLAB_PROJECT_ID", env_values, env_path).strip()

    issue_data = gitlab.get(f"/projects/{quote(env_project, safe='')}/issues/{args.issue_iid}")
    description = issue_data.get("description") or ""
    service_desk_email = parse_issue_service_desk_email(issue_data)
    ticket_path = merge_and_write_ticket(
        project_root,
        args.issue_iid,
        {
            "issue_iid": str(args.issue_iid),
            "issue_title": issue_data.get("title") or "",
            "issue_url": issue_data.get("web_url") or "",
            "issue_state": issue_data.get("state") or "",
            "issue_created_at": issue_data.get("created_at") or "",
            "labels": issue_data.get("labels") or [],
            "author": {
                "username": (issue_data.get("author") or {}).get("username") or "",
                "name": (issue_data.get("author") or {}).get("name") or "",
            },
            "service_desk_reply_to": service_desk_email or "",
            "gitlab_project_id": env_project,
            "workflow_status": "pendiente",
            "validations": {
                "gitlab_issue_loaded": True,
            },
        },
    )
    milestone_title = build_monthly_milestone_title(issue_data.get("created_at") or "")
    milestone = None
    milestone_created = False
    sidot_user_query = (
        args.sidot_user_query.strip()
        or parse_issue_username(description)
        or service_desk_email
        or parse_issue_full_name(description)
    )
    if not sidot_user_query:
        raise RuntimeError("Could not determine SIDOT user query. Pass --sidot-user-query explicitly.")

    search_resp = sidot.get(f"/pref/usuario/?busqueda.query={quote(sidot_user_query, safe='')}")
    search_resp.raise_for_status()
    edit_links = parse_user_edit_links(search_resp.text)
    if not edit_links:
        raise RuntimeError(f"No SIDOT user edit link found for query: {sidot_user_query}")
    if len(edit_links) > 1:
        raise RuntimeError(f"SIDOT query is ambiguous; found {len(edit_links)} users for query: {sidot_user_query}")
    edit_link = edit_links[0]

    solicitante_nombre = resolve_applicant_name(
        args.solicitante_nombre.strip(),
        description,
        sidot_user_query,
        search_resp.text,
        edit_link,
    )
    saludo = build_saludo(solicitante_nombre, args.sexo.strip() or None)
    ticket_path = merge_and_write_ticket(
        project_root,
        args.issue_iid,
        {
            "sidot_user_query": sidot_user_query,
            "solicitante_nombre": solicitante_nombre,
            "applicant": {
                "full_name": solicitante_nombre,
                "service_desk_reply_to": service_desk_email or "",
            },
            "sidot_user": {
                "edit_link_with_state": edit_link,
            },
            "validations": {
                "gitlab_issue_loaded": True,
                "sidot_search_unique_match": True,
                "applicant_name_resolved": True,
            },
        },
    )

    start_note = None
    if not args.skip_start_note and "Estado: En proceso" not in (issue_data.get("labels") or []):
        note_start = (
            f"{saludo},\n\n"
            "Su solicitud está siendo tramitada, se ha solicitado la autorización al equipo que administra la plataforma SIDOT, "
            "teniendo su aprobación procederemos a generar una nueva clave y se la enviaremos por este mismo medio.\n\n"
            "Tenga en cuenta que el proceso puede demorarse hasta 24hs.\n\n"
            "Atte,\n\n"
            "Equipo Mesa de Ayuda SIDOT"
        )
        require_confirmation(
            "Modificar GitLab: publicar nota inicial y etiquetar issue en proceso.",
            [
                f"Proyecto: {env_project}",
                f"Issue IID: {args.issue_iid}",
                'Etiqueta a agregar: Estado: En proceso',
                "Comentario: solicitud en proceso",
            ],
        )
        start_note = gitlab.post(f"/projects/{quote(env_project, safe='')}/issues/{args.issue_iid}/notes", form={"body": note_start})
        gitlab.put(f"/projects/{quote(env_project, safe='')}/issues/{args.issue_iid}", form={"add_labels": "Estado: En proceso"})
        ticket_path = merge_and_write_ticket(
            project_root,
            args.issue_iid,
            {
                "workflow_status": "en proceso",
                "start_note_id": start_note.get("id"),
                "labels": sorted(set((issue_data.get("labels") or []) + ["Estado: En proceso"])),
            },
        )

    edit_url = urljoin(f"{sidot.base_url}/", edit_link.lstrip("/"))
    edit_response = sidot.get(edit_url)
    edit_response.raise_for_status()
    sidot_user_id_match = re.search(r"/pref/usuario/edit/(\d+)", edit_link)
    ticket_path = merge_and_write_ticket(
        project_root,
        args.issue_iid,
        {
            "sidot_user": {
                "usuarioId": sidot_user_id_match.group(1) if sidot_user_id_match else "",
                "login": args.sidot_login.strip() or sidot_user_query,
                "url": re.sub(r"\?state=.*$", "", edit_link),
                "edit_link_with_state": edit_link,
                "estado": "habilitado",
            },
            "validations": {
                "gitlab_issue_loaded": True,
                "sidot_search_unique_match": True,
                "applicant_name_resolved": True,
                "sidot_user_edit_page_loaded": True,
            },
        },
    )

    soup = BeautifulSoup(edit_response.text, "html.parser")
    form = soup.find("form")
    if form is None:
        raise RuntimeError("Could not find edit form in SIDOT user page.")

    action = form.get("action") or edit_url
    post_url = urljoin(edit_url, action)

    new_password = generate_password(20)
    payload = collect_password_reset_payload(form, new_password)
    password_fields = ["contrasenaNew"]
    confirmation_fields = ["contrasenaRepeat"]

    require_confirmation(
        "Modificar SIDOT: reiniciar clave del usuario.",
        [
            f"Usuario SIDOT: {edit_url}",
            f"Login de verificacion: {args.sidot_login.strip() or sidot_user_query}",
            "La clave temporal no se imprimira en esta confirmacion.",
        ],
    )
    save_response = sidot.session.post(post_url, data=payload, headers={"Referer": edit_url}, timeout=30)
    save_response.raise_for_status()
    ticket_path = merge_and_write_ticket(
        project_root,
        args.issue_iid,
        {
            "workflow_status": "clave reiniciada",
            "validations": {
                "gitlab_issue_loaded": True,
                "sidot_search_unique_match": True,
                "applicant_name_resolved": True,
                "sidot_user_edit_page_loaded": True,
                "sidot_password_reset_posted": True,
            },
        },
    )

    verification_login = args.sidot_login.strip() or sidot_user_query
    verification_client = SidotClient(base_url=sidot.base_url, username=verification_login, password=new_password)
    verification_metadata = verification_client.login()
    if not verification_metadata.get("authenticated"):
        raise RuntimeError(f"SIDOT login verification failed for {verification_login}.")
    ticket_path = merge_and_write_ticket(
        project_root,
        args.issue_iid,
        {
            "workflow_status": "verificado",
            "sidot_user": {
                "usuarioId": (load_ticket(project_root, args.issue_iid).get("sidot_user") or {}).get("usuarioId", ""),
                "login": verification_login,
                "url": (load_ticket(project_root, args.issue_iid).get("sidot_user") or {}).get("url", ""),
                "edit_link_with_state": (load_ticket(project_root, args.issue_iid).get("sidot_user") or {}).get("edit_link_with_state", ""),
                "estado": "habilitado",
            },
            "validations": {
                "gitlab_issue_loaded": True,
                "sidot_search_unique_match": True,
                "applicant_name_resolved": True,
                "sidot_user_edit_page_loaded": True,
                "sidot_password_reset_posted": True,
                "sidot_login_verified": True,
            },
            },
        )

    if not args.skip_close:
        milestone = gitlab.find_project_milestone(env_project, milestone_title)
        require_milestone_confirmation(env_project, args.issue_iid, milestone_title, milestone is not None)
        if milestone is None:
            milestone = gitlab.create_project_milestone(env_project, milestone_title)
            milestone_created = True
        ticket_path = merge_and_write_ticket(
            project_root,
            args.issue_iid,
            {
                "milestone": {
                    "id": str(milestone.get("id") or ""),
                    "iid": str(milestone.get("iid") or ""),
                    "title": milestone.get("title") or milestone_title,
                    "web_url": milestone.get("web_url") or "",
                    "created": milestone_created,
                },
                "workflow_status": "milestone asignado",
                "validations": {
                    "gitlab_issue_loaded": True,
                    "sidot_search_unique_match": True,
                    "applicant_name_resolved": True,
                    "sidot_user_edit_page_loaded": True,
                    "sidot_password_reset_posted": True,
                    "sidot_login_verified": True,
                    "milestone_assigned": True,
                },
            },
        )

    note_end = (
        f"{saludo},\n\n"
        "A continuación su nueva clave de acceso temporal, se recomienda cambiar la misma ni bien logre tener acceso a la plataforma.\n\n"
        f"{new_password}\n\n"
        "Atte,\n\n"
        "Equipo Mesa de Ayuda SIDOT"
    )
    gitlab_finish_details = [
        f"Proyecto: {env_project}",
        f"Issue IID: {args.issue_iid}",
        "Comentario: entrega de clave temporal",
    ]
    if not args.skip_close:
        gitlab_finish_details.extend([
            'Etiqueta a remover: Estado: En proceso',
            'Etiqueta a agregar: Estado: Cerrado',
            f"Milestone: {milestone_title}",
            "Accion: cerrar issue",
        ])
    require_confirmation(
        "Modificar GitLab: publicar clave temporal y actualizar cierre.",
        gitlab_finish_details,
    )
    end_note = gitlab.post(f"/projects/{quote(env_project, safe='')}/issues/{args.issue_iid}/notes", form={"body": note_end})

    if not args.skip_close:
        gitlab.put(
            f"/projects/{quote(env_project, safe='')}/issues/{args.issue_iid}",
            form={
                "remove_labels": "Estado: En proceso",
                "add_labels": "Estado: Cerrado",
                "state_event": "close",
                "milestone_id": str((milestone or {}).get("id") or ""),
            },
        )
    ticket_path = merge_and_write_ticket(
        project_root,
        args.issue_iid,
        {
            "workflow_status": "cerrado" if not args.skip_close else "clave entregada",
            "end_note_id": end_note.get("id"),
            "issue_state": "closed" if not args.skip_close else issue_data.get("state") or "",
            "milestone": (
                {
                    "id": str((milestone or {}).get("id") or ""),
                    "iid": str((milestone or {}).get("iid") or ""),
                    "title": (milestone or {}).get("title") or milestone_title,
                    "web_url": (milestone or {}).get("web_url") or "",
                    "created": milestone_created,
                }
                if not args.skip_close
                else (load_ticket(project_root, args.issue_iid).get("milestone") or {})
            ),
            "labels": (
                sorted(({label for label in (issue_data.get("labels") or []) if label != "Estado: En proceso"} | {"Estado: Cerrado"}))
                if not args.skip_close
                else sorted(set((issue_data.get("labels") or []) + ["Estado: En proceso"]))
            ),
            "validations": {
                "gitlab_issue_loaded": True,
                "sidot_search_unique_match": True,
                "applicant_name_resolved": True,
                "sidot_user_edit_page_loaded": True,
                "sidot_password_reset_posted": True,
                "sidot_login_verified": True,
                "gitlab_closure_applied": not args.skip_close,
                "milestone_assigned": not args.skip_close,
            },
        },
    )

    print("Password reset workflow completed.")
    print(f"Issue IID: {args.issue_iid}")
    print(f"SIDOT query: {sidot_user_query}")
    print(f"SIDOT edit URL: {edit_url}")
    print(f"SIDOT password fields updated: {', '.join(password_fields)}")
    print(f"SIDOT password confirmation fields updated: {', '.join(confirmation_fields)}")
    print(f"SIDOT temporary login verified: {verification_metadata.get('authenticated')}")
    print(f"GitLab start note id: {start_note.get('id') if start_note else '-'}")
    print(f"GitLab final note id: {end_note.get('id')}")
    print(f"Issue closed: {not args.skip_close}")
    print(f"Milestone title: {milestone_title if not args.skip_close else '-'}")
    print(f"Milestone id: {(milestone or {}).get('id') if not args.skip_close else '-'}")
    print(f"Ticket JSON: {ticket_path}")
    print(f"Ticket CSV index: {ticket_index_csv_path(project_root)}")



if __name__ == "__main__":
    main()
