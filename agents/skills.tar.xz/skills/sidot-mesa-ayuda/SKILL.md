---
name: sidot-mesa-ayuda
description: "Gestionar solicitudes de reinicio de clave SIDOT en GitLab siguiendo el protocolo oficial de Mesa de Ayuda. Usar cuando se necesite triage, validación, respuesta y cierre de issues/work items de acceso SIDOT, incluyendo la asignación de un milestone mensual al cerrar cada ticket. Este skill debe apoyarse en el skill gitlab-connect para listar y actualizar work items/milestones, y en el skill sidot-connect para consultar/validar datos del usuario en la plataforma SIDOT."
---

# SIDOT Mesa Ayuda

## Objetivo

Ejecutar el flujo de Mesa de Ayuda SIDOT para solicitudes de clave, desde la revisión del work item hasta su cierre, usando respuestas estandarizadas y validaciones obligatorias.

## Flujo Operativo

1. Obtener y registrar trabajo pendiente:
- Usar el skill `gitlab-connect` para listar work items/issues asignados (priorizar estado `opened`).
- Filtrar **obligatoriamente** por `GITLAB_PROJECT_ID` definido en `.env`.
- Guardar metadata relevante (IID, título, autor, URL, etiquetas) en `doc/.sidot/git-tickets/ticket_<iid>.json`, incluyendo siempre `issue_created_at` desde GitLab.
- Al regenerar `doc/.sidot/git-tickets/index.csv`, usar `issue_created_at` como fecha principal y `updated_at` como fallback si falta `issue_created_at`.
- Para crear o actualizar `ticket_<iid>.json`, usar `./assets/ticket_example.json` como plantilla de referencia para la estructura esperada y los campos operativos a mantener.
- Identificar el item objetivo y leer título, descripción, comentarios y datos del solicitante.
- Antes de analizar casos locales o regenerar el índice, usar `python3 .agents/skills/sidot-mesa-ayuda/assets/sync_sidot_git_tickets.py --project-root "$PWD"` para refrescar `doc/.sidot/git-tickets/` desde GitLab.

2. Validar datos mínimos del solicitante:
- Nombre completo, RUT, Institución, Correo de uso exclusivo.
- El correo del solicitante debe obtenerse siempre desde el campo GitLab `service_desk_reply_to` de `GET /projects/<GITLAB_PROJECT_ID>/issues/<issue_iid>`. No usar la descripción del issue ni el autor `support-bot` como fuente del correo.
- Si faltan datos críticos, responder con plantilla de información incompleta, cerrar el issue y asignar inmediatamente el milestone mensual derivado de `issue_created_at`.
- Actualizar `doc/.sidot/git-tickets/ticket_<iid>.json` con los datos extraídos del solicitante y regenerar `index.csv`.

3. Verificar elegibilidad en SIDOT:
- Usar el skill `sidot-connect` para buscar al usuario.
- **Obligatorio**: Validar existencia y estado (habilitado) antes de proceder.
- Guardar `usuarioId`, `login`, estado y link directo del usuario SIDOT sin parámetro `state` (`sidot_user.url`, formato `/pref/usuario/edit/<usuarioId>`) en `doc/.sidot/git-tickets/ticket_<iid>.json` para el ticket correspondiente.
- Si no existe o está deshabilitado, responder con plantilla de rechazo por alcance, cerrar el issue y asignar inmediatamente el milestone mensual derivado de `issue_created_at`. **Antes de modificar GitLab**, pedir confirmación explícita al usuario indicando el issue, comentario/etiqueta/estado a aplicar y esperar aprobación.

4. Iniciar tramitación:
- **Antes de modificar GitLab**, pedir confirmación explícita al usuario indicando el issue, comentario/etiqueta/estado a aplicar y esperar aprobación.
- Publicar plantilla de "en proceso".
- Cambiar etiquetas/estado del work item a en curso.
- Actualizar el JSON del ticket con estado operacional y regenerar `index.csv`.
- Enviar solicitud de validación al equipo administrador SIDOT. Para esto generar un link en formato "mailto:" y entregarlo por pantalla al usuario.

5. Aplicar reinicio de clave:
- Leer `usuarioId` y `login` desde `doc/.sidot/git-tickets/ticket_<iid>.json` para asegurar consistencia.
- Generar clave temporal robusta de 20 caracteres con símbolos.
- **Antes de modificar SIDOT**, pedir confirmación explícita al usuario indicando `usuarioId`, `login` y acción de reinicio de clave, sin exponer la clave temporal.
- Aplicar cambio de clave en SIDOT.
- **Obligatorio**: Verificar que el login con la nueva clave funciona antes de informar al usuario.
- Registrar en el JSON del ticket que la verificación post-cambio fue exitosa, sin persistir la clave temporal en disco.

6. Informar y cerrar:
- **Antes de modificar GitLab**, pedir confirmación explícita al usuario indicando el comentario de entrega, el milestone mensual a asignar y el cierre/etiquetas a aplicar.
- Publicar plantilla de entrega de clave temporal.
- Marcar item como cerrado, asignar el milestone mensual `Mantenciones Mes YYYY`, y actualizar estado en `doc/.sidot/git-tickets/ticket_<iid>.json` y `index.csv`.

## Reglas

- **Confirmación obligatoria antes de modificar datos**: Antes de cualquier acción que modifique datos en GitLab o SIDOT, pedir confirmación explícita al usuario y esperar respuesta afirmativa. Esto aplica a publicar notas, cambiar etiquetas, asignar o crear milestones, cerrar/reabrir issues, cambiar estado de work items, reiniciar claves, guardar formularios SIDOT o cualquier `POST`/`PUT`/`PATCH`/`DELETE` con efecto persistente. No asumir confirmación por contexto, urgencia, automatización o ejecución previa.
- **Cierre con milestone obligatorio**: Todo flujo que cierre un issue debe asignar el milestone mensual correspondiente inmediatamente después del cierre. Esto aplica a rechazo por alcance, solicitud incompleta y entrega/cierre final.
- **Lecturas sin confirmación**: Consultas `GET`, búsquedas, validaciones y generación de `mailto:` no requieren confirmación si no persisten cambios en GitLab o SIDOT.
- **Persistencia de Datos**: Mantener la carpeta `doc/.sidot/git-tickets/` con un archivo por ticket (`ticket_<iid>.json`) y un resumen `index.csv` con columnas `id,fecha,estado,nombre solicitante,json file name`.
- El campo `fecha` del CSV debe derivarse de `issue_created_at`; si no existe, usar `updated_at`.
- El campo `nombre solicitante` del CSV debe derivarse de `applicant.full_name`, `applicant.name`, `solicitante.nombre_completo`, `solicitante.nombre` o `solicitante_nombre`, en ese orden.
- **Estructura del JSON**: Al crear o actualizar `doc/.sidot/git-tickets/ticket_<iid>.json`, tomar `./assets/ticket_example.json` como referencia base de estructura y nomenclatura de campos, adaptándolo al caso real sin inventar valores.
- **Seguridad de Persistencia**: No guardar la clave temporal en los JSON; solo persistir metadata operativa, validaciones, referencias SIDOT/GitLab y estado del flujo.
- **Validación Previa**: No intentar modificar una clave sin haber validado primero la existencia y estado activo del usuario en SIDOT.
- **Verificación Post-Acción**: Tras un cambio de clave, realizar una prueba de login (vía script o manual) para confirmar que la nueva clave es válida.
- No inventar datos del solicitante ni del usuario SIDOT.
- No exponer tokens, credenciales ni datos sensibles en logs.
- Mantener trazabilidad: registrar qué validaciones se realizaron.
- Usar plantillas de `assets/` y adaptarlas al caso concreto.
- En la solicitud de validación a administradores MINSAL, incluir siempre el `Link usuario SIDOT` tomado desde `sidot_user.url`.
- En comentarios al solicitante, reemplazar `Estimad@` por saludo personalizado según nombre+sexo.
- Nunca usar correo (`service_desk_reply_to`) ni login SIDOT como nombre en el saludo; si no se puede determinar nombre completo de forma confiable, solicitar `--solicitante-nombre` antes de publicar comentarios.
- Si hay ambigüedad de identidad (RUT/correo no coinciden), pausar cierre y solicitar aclaración.
- El alcance de consulta en GitLab debe restringirse **siempre** al proyecto `GITLAB_PROJECT_ID`.

## Recursos

- **Carpeta de Tickets**: `doc/.sidot/git-tickets/`
- **Resumen CSV**: `doc/.sidot/git-tickets/index.csv`
- **Visor HTML local**: `assets/ticket_viewer.html` muestra fechas en zona horaria del usuario con formato `YYYY-MM-DD HH:MM`.
- **Ejemplo de ticket JSON**: `./assets/ticket_example.json`
- **Sincronizador local**: `.agents/skills/sidot-mesa-ayuda/assets/sync_sidot_git_tickets.py` refresca los JSON e `index.csv` desde GitLab sin tocar GitLab ni SIDOT.
- Plantillas de comentario y correo: `assets/templates.md`
- Plantilla de checklist operativo: `assets/checklist.md`
- Plantilla de resumen de resolución: `assets/resumen-cierre.md`
- Automatización de reset/cierre: `assets/reset_password_from_issue.py`

## Comandos de Referencia

Usar como base operativa los comandos definidos en:

- Skill `gitlab-connect`: listar proyectos, work items/issues y comentar/cerrar.
- Skill `sidot-connect`: búsqueda y validación del usuario SIDOT, y actualización de clave.
- Sincronización local de tickets: `python3 .agents/skills/sidot-mesa-ayuda/assets/sync_sidot_git_tickets.py --project-root "$PWD"`.

Condición obligatoria para este skill:

- Toda consulta de work items/issues debe ejecutarse con filtro de proyecto `GITLAB_PROJECT_ID`.


## Ejecución asistida (automatizada)

Comando recomendado para resolver un issue de clave de punta a punta:

```bash
python3 .agents/skills/sidot-mesa-ayuda/assets/reset_password_from_issue.py \
  --project-root "$PWD" \
  --issue-iid 102
```

La automatización debe solicitar confirmación interactiva antes de cada modificación persistente en GitLab o SIDOT. Si la ejecución no tiene terminal interactiva, debe detenerse antes de modificar datos.

Opcional:

- `--sidot-user-query "Cmiranda"` para forzar la búsqueda del usuario SIDOT.
- Si no se informa `--sidot-user-query`, el script intenta inferir la búsqueda desde `Usuario`, `usuario sidot`, `login`, `service_desk_reply_to` o `Nombre completo` del issue.
- `--solicitante-nombre "Juan Carlos Pérez"` para fijar saludo.
- `--sexo M|F` para fijar tratamiento (`Estimado`/`Estimada`) cuando la inferencia no sea clara.
- `--skip-start-note` para no publicar nuevamente la plantilla "en proceso" cuando el issue ya fue tramitado y solo falta aplicar el reinicio aprobado.
- `--skip-close` para publicar clave temporal sin cerrar inmediatamente el issue.

Notas de implementación:

- Para reiniciar clave en `/pref/usuario/save`, enviar estos campos del formulario de edición: `__csrftoken`, `usuarioId`, `state`, `contrasenaNew`, `contrasenaRepeat`, `hospitalesProcuramientoIds` y `hospitalesTrasplantesIds`.
- Enviar `hospitalesProcuramientoIds` y `hospitalesTrasplantesIds` como campos repetidos cuando tengan más de un valor. Si el `select multiple` viene vacío en el HTML inicial, tomar los valores desde `struts.hiddenHospitalesProcuramientoIds[data-values]` y `struts.hiddenHospitalesTrasplantesIds[data-values]`.
- No enviar el formulario completo de usuario para un reinicio de clave: otros `select` dependientes se completan por JavaScript y el POST completo puede volver al formulario sin persistir la nueva clave.
- Al cerrar, la automatización agrega `Estado: Cerrado`, remueve `Estado: En proceso` y ejecuta `state_event=close`.
- Al cerrar, la automatización crea o reutiliza el milestone mensual derivado de `issue_created_at` con nombre `Mantenciones Mes YYYY`, pero solo después de una confirmación explícita adicional del usuario antes de publicar el milestone.
- Los flujos de rechazo por alcance, solicitud incompleta y entrega de clave temporal también deben seguir la regla de cierre con milestone.
- Si la búsqueda de usuario SIDOT devuelve más de una cuenta editable, la automatización se detiene por ambigüedad.

## Integración API Skills

- Conectividad GitLab: usar cliente de `gitlab-connect` (`assets/api.py`).
- Conectividad SIDOT: usar cliente de `sidot-connect` (`assets/api.py`).
- Evitar duplicar lógica HTTP directa del servicio en este skill.
- El sincronizador `.agents/skills/sidot-mesa-ayuda/assets/sync_sidot_git_tickets.py` debe usar `GitLabClient` y escribir solo en `doc/.sidot/git-tickets/`.

Métodos usados por este skill:
- GitLab:
  - `GitLabClient.get("/projects/<id>/issues/<iid>")`
  - `GitLabClient.get("/projects/<id>/issues", query={"state": "all", "per_page": 100, "order_by": "created_at", "sort": "asc", "page": N})` para sincronizar el índice local
  - `GitLabClient.post("/projects/<id>/issues/<iid>/notes", form={"body": ...})`
  - `GitLabClient.put("/projects/<id>/issues/<iid>", form={"add_labels": ..., "remove_labels": ..., "state_event": "close"})`
  - `GitLabClient.find_project_milestone(project_id, title)`
  - `GitLabClient.create_project_milestone(project_id, title, ...)`
  - `GitLabClient.assign_issue_milestone(project_id, issue_iid, milestone_id)`
- SIDOT:
  - `SidotClient.login()`
  - `SidotClient.get("/pref/usuario/?busqueda.query=...")`
  - `SidotClient.session.post("/pref/usuario/save", data={...})` para persistir cambio de clave con cookies de sesión y payload mínimo.
