---
name: sidot-connect
description: "Navegar SIDOT vía sesión autenticada para obtener datos operativos: login, búsqueda de donante por código SIDOT, consulta de extracciones por donante_id y utilidades de catálogo de hospitales."
---

# SIDOT Web Navigator

## Objetivo

Obtener datos desde SIDOT de forma reproducible usando scripts:

- Login autenticado y obtención de cookie de sesión.
- Búsqueda de donante por código SIDOT.
- Búsqueda de extracciones por `donante_id` con resolución de `trasplante_id`.
- Búsqueda de seguimiento de trasplante para resolver `trasplante_id` de receptores.
- Búsqueda de usuarios en SIDOT por texto libre.
- Validación de login para un usuario SIDOT específico sin persistir ni imprimir la clave.
- Exportación de hospitales SIDOT.
- Login vía curl pegado desde el navegador, ya sea puntual (`sidot_login_from_curl.py`) o configurado
  en `.env`/entorno vía `SIDOT_CURL` (fallback cuando el login por credenciales no pasa el challenge
  de Cloudflare en `/login`; la sesión resultante la reutilizan automáticamente todos los métodos
  expuestos por este skill).

## Dependencia: binario `curl`

Este skill ejecuta todas sus requests HTTP con el binario `curl` del sistema (vía subprocess), no con
la librería Python `requests`. Se verificó empíricamente que Cloudflare, frente a SIDOT, bloquea el
fingerprint TLS/HTTP de `requests` (403 "Just a moment...") incluso reproduciendo exactamente las
mismas cookies y headers que sí funcionan con `curl` real. Por eso `curl` debe estar instalado y en
el `PATH` de donde se ejecuten los scripts (ver `assets/curl_transport.py`).

## Variables `.env`

Requeridas:

- `SIDOT_USER`
- `SIDOT_PWD`
- `SIDOT_URL` (ej: `https://sidot.minsal.cl`)

Opcional:

- `SIDOT_CURL`: comando curl completo ("Copiar como cURL" del navegador) de una request autenticada
  a SIDOT. Se usa cuando Cloudflare bloquea el login por credenciales (ver "Reglas de trabajo"). Puede
  definirse en `.env` o como variable de entorno del proceso (el entorno tiene prioridad sobre `.env`).

## Tabla `PROGRAMA_TRASPLANTE_ID`

Usar estos IDs al consultar `/seguimiento/trasplante/`:

| `PROGRAMA_TRASPLANTE_ID` | Programa |
|---|---|
| `1` | Riñón |
| `2` | Pulmón |
| `3` | Pancreas |
| `4` | Hígado |
| `5` | Corazón |

## Comandos

```bash
# 1) Login y persistencia de sesión
python3 .agents/skills/sidot-connect/assets/sidot_login.py --project-root "$PWD"

# 1b) Si 1) falla con 403 / "Cf-Mitigated: challenge" (Cloudflare bloquea /login), hay dos formas
#     equivalentes de pegar un curl copiado del navegador (Network tab -> "Copy as cURL") de
#     cualquier request autenticado a SIDOT hecho justo después de iniciar sesión
#     (ej. GET /donante/ o GET /pref/hospital/?pageIndex=0):

#   - Puntual: pasar el curl directamente a este script.
python3 .agents/skills/sidot-connect/assets/sidot_login_from_curl.py --project-root "$PWD"

#   - Persistente: definir SIDOT_CURL en .env (o como variable de entorno) con el mismo curl.
#     Cualquier método del skill lo detecta y persiste la sesión automáticamente, sin correr
#     ningún script de login aparte; solo hay que refrescar SIDOT_CURL cuando la sesión expire.
#     export SIDOT_CURL="curl 'https://sidot.minsal.cl/donante/?busqueda=' -H 'cookie: ...' -H 'user-agent: ...'"

# 2) Buscar donante por código SIDOT
python3 .agents/skills/sidot-connect/assets/sidot_search_donante.py --project-root "$PWD" --codigo-sidot "$CODIGO_SIDOT"

# 3) Buscar extracciones por donante_id
python3 .agents/skills/sidot-connect/assets/sidot_search_extracciones.py --project-root "$PWD" --donante-id "$DONANTE_ID"

# 4) Exportar catálogo de hospitales
python3 .agents/skills/sidot-connect/assets/fetch_hospitales.py --project-root "$PWD"
python3 .agents/skills/sidot-connect/assets/fetch_hospitales.py --project-root "$PWD" --stdout

# 5) Buscar usuarios en SIDOT
python3 .agents/skills/sidot-connect/assets/sidot_search_usuarios.py --project-root "$PWD" --query "$USUARIO_QUERY"

# 6) Validar login de un usuario SIDOT sin imprimir la clave
printf '%s' "$CLAVE_TEMPORAL" | python3 .agents/skills/sidot-connect/assets/sidot_verify_login.py --project-root "$PWD" --username "$USERNAME" --password-stdin --stdout

# Salida esperada explícita:
# $PROJECT_ROOT/doc/.sidot/hospitales.json
```

## Salidas

- Sesión/cookies: `doc/.sidot/session/cookies.json` (incluye `source`: `"credentials"`, `"curl_env"` (desde `SIDOT_CURL`) o `"curl"` (desde `sidot_login_from_curl.py`); `headers` presente en los dos últimos casos)
- Última respuesta login/probe: `doc/.sidot/session/login_response.html`
- Búsqueda donante:
  - HTML: `doc/.sidot/donante_search/donante_<codigo>.html`
  - JSON parseado: `doc/.sidot/donante_search/donante_<codigo>.json`
- Extracciones:
  - HTML: `doc/.sidot/extracciones/extracciones_donante_<id>.html`
  - JSON parseado: `doc/.sidot/extracciones/extracciones_donante_<id>.json`
  - HTML detalle por extraíble (cuando aplica fallback): `doc/.sidot/extracciones/extraible_<donante_id>_<extraible_id>.html`
- Hospitales:
  - JSON: `$PROJECT_ROOT/doc/.sidot/hospitales.json` (ejemplo: `doc/.sidot/hospitales.json`)
- Usuarios:
  - HTML: `doc/.sidot/usuarios/usuarios_<query>.html`
  - JSON parseado: `doc/.sidot/usuarios/usuarios_<query>.json`
- Validación de clave:
  - No persiste archivos ni imprime la clave.
  - Salida segura por consola: usuario, `authenticated`, `auth_url`, `status_code` y timestamp.

## Reglas de trabajo

- Nunca hardcodear usuario o contraseña.
- Cargar credenciales solo desde `.env` del `--project-root`.
- Para validar claves temporales, preferir `--password-stdin`; no registrar claves en consola, bitácoras ni archivos.
- Mantener outputs bajo `doc/.sidot/`.
- Si falla login, no intentar scrapear páginas de negocio.
- Si SIDOT antepone un challenge de Cloudflare a `/login` (respuesta 403, título "Just a moment...",
  header `Cf-Mitigated: challenge`), el login por credenciales no puede resolverlo (`/login` está
  protegido para cualquier cliente sin `cf_clearance` vigente, incluyendo `curl`): usar `SIDOT_CURL`
  (o `sidot_login_from_curl.py`) para persistir una sesión ya autenticada desde el navegador.
- El challenge de Cloudflare puede aparecer de forma intermitente incluso para una sesión ya
  autenticada (se observó la misma request fallar y, segundos después, funcionar sin cambios). Por
  eso `is_session_authenticated` reintenta un par de veces antes de declarar la sesión inválida; si
  un script puntual falla con 403/"Just a moment...", reintentar suele bastar.
- Orden de resolución de sesión en `build_authenticated_session` (usado por todo el skill):
  1. Reutilizar `doc/.sidot/session/cookies.json` si sigue autenticada.
  2. Si no, construir sesión desde `SIDOT_CURL` (env var o `.env`) y persistirla.
  3. Si no hay `SIDOT_CURL`, intentar login por credenciales (`SIDOT_USER`/`SIDOT_PWD`).
  - Esto aplica igual a `sidot_login.py`, `sidot_search_donante.py`, `sidot_search_extracciones.py`,
    `sidot_search_usuarios.py` y `fetch_hospitales.py`: ninguno reimplementa lógica de sesión propia.
- Resolución de IDs:
  - `sidot_search_donante.py` detecta `donante_id` desde rutas `/donante/identificacion/<id>` y equivalentes.
  - `sidot_search_extracciones.py` primero busca `trasplante_id` en el listado y, si no aparece, abre cada detalle `/donante/extraccion/extraible/<donante>/<extraible>` para detectar enlaces `/trasplante/<id>`.
  - Para receptores en seguimiento, resolver `trasplante_id` desde `/seguimiento/trasplante/` con estos criterios:
    - incluir siempre `busqueda.programaTrasplanteId`,
    - incluir siempre `busqueda.fechaTrasplanteDesde=01/01/1900`,
    - preferir `busqueda.codigoIsp`,
    - si no hay `codigoIsp`, usar `busqueda.nombre`,
    - si no se conoce el programa, iterar por todos los programas posibles.
  - Si la búsqueda es por `codigoIsp`, validar que el nombre retornado coincida con el esperado antes de aceptar el `trasplante_id`.

Ejemplos de búsqueda de seguimiento:

```text
/seguimiento/trasplante/?busqueda.programaTrasplanteId=4&busqueda.fechaTrasplanteDesde=01/01/1900&busqueda.codigoIsp=47126
```

```text
/seguimiento/trasplante/?busqueda.programaTrasplanteId=4&busqueda.fechaTrasplanteDesde=01/01/1900&busqueda.nombre=JORGE%20ARTURO%20HIDALGO%20TAPIA
```

## API Reutilizable

- Cliente compartido: `.agents/skills/sidot-connect/assets/api.py`
- Clase principal: `SidotClient`
- Scripts del skill deben autenticarse y navegar SIDOT a través de este cliente.
- Para probar credenciales de usuarios finales, usar `assets/sidot_verify_login.py` con `SidotClient(base_url, username, password)` y no `SidotClient.from_project_root`, ya que este último usa las credenciales administrativas del `.env`.

### Contrato API (`assets/api.py`)

Funciones utilitarias:
- `load_env_file(env_path: Path) -> dict[str, str]`
- `env_get(key, env_values, env_path, required=True) -> str`
- `extract_csrf_token(html_text: str) -> str`: extrae `__csrftoken` desde `/login`.

Clase:
- `SidotClient(base_url: str, username: str, password: str)`
- `SidotClient.from_project_root(project_root: Path) -> SidotClient`:
  - Requiere `SIDOT_URL`, `SIDOT_USER`, `SIDOT_PWD`.
- `login() -> dict`:
  - Flujo: `GET /login` -> extrae CSRF -> `POST /logon`.
  - Devuelve metadata de autenticación (`auth_url`, `status_code`, `authenticated`, etc.).
- `ensure_login() -> None`: ejecuta login si no hay sesión autenticada.
- `get(path_or_url: str, **kwargs) -> CurlResponse`:
  - Si recibe URL absoluta, la usa directamente.
  - Si recibe ruta relativa, concatena con `SIDOT_URL`.
  - Usa la sesión autenticada (`CurlSession`, `assets/curl_transport.py`) del cliente.

Comportamiento de sesión:
- `SidotClient.session` (`CurlSession`) queda disponible para `POST`/`GET` avanzados cuando se necesita mantener cookies; cada llamada ejecuta `curl` como subprocess sobre un cookie-jar propio del proceso.
- Headers browser-like por defecto (`User-Agent`, `Accept`, `Accept-Language`).

Errores:
- `RuntimeError` si falla CSRF o autenticación.
- `CurlError` (`assets/curl_transport.py`) si `curl` termina con código distinto de 0, o vía `raise_for_status()` en respuestas >= 400.

Ejemplo:
```python
from pathlib import Path
from api import SidotClient

client = SidotClient.from_project_root(Path("/ruta/proyecto"))
client.login()
donantes = client.get("/donante/?busqueda=&busqueda.codigoSidot=<CODIGO_SIDOT>")
usuarios = client.get("/pref/usuario/?busqueda.query=<USUARIO_QUERY>")
seguimiento = client.get("/seguimiento/trasplante/?busqueda.programaTrasplanteId=<PROGRAMA_TRASPLANTE_ID>&busqueda.fechaTrasplanteDesde=01/01/1900&busqueda.codigoIsp=<CODIGO_ISP>")
```

### Contrato de sesión (`assets/sidot_common.py`)

- `build_authenticated_session(project_root) -> (session, metadata)`:
  - Reutiliza `doc/.sidot/session/cookies.json` si sigue autenticada (`is_session_authenticated`).
  - Si no, intenta `build_session_from_curl_env` (lee `SIDOT_CURL`); si `SIDOT_CURL` está definido pero
    la sesión no autentica, lanza `RuntimeError` de inmediato (no cae a credenciales).
  - Si no hay `SIDOT_CURL`, hace login por credenciales vía `SidotClient`; si falla (típicamente
    Cloudflare bloqueando `/login`), lanza `RuntimeError` indicando definir `SIDOT_CURL` o usar
    `sidot_login_from_curl.py`.
  - `metadata["source"]` indica el origen de la sesión: `"credentials"`, `"curl_env"` o `"curl"`.
  - Es la única función de sesión que usan los scripts del skill; ninguno reimplementa esta lógica.
- `read_curl_env(project_root, key="SIDOT_CURL") -> str | None`: lee la variable desde el entorno del
  proceso primero, luego desde `.env`; solo despoja un par de comillas envolventes (la convención de
  `.env`), nunca las comillas internas del propio curl.
- `build_session_from_curl_env(project_root) -> (session, metadata) | (None, None)`: envoltura de
  `persist_session_from_curl` para `SIDOT_CURL`, con `source="curl_env"`.
- `persist_session_from_curl(project_root, curl_text, source="curl") -> (session, metadata)`:
  construye la sesión desde un curl pegado, verifica que autentique, y persiste `cookies.json` +
  `login_response.html`. Usado tanto por `sidot_login_from_curl.py` como por `SIDOT_CURL`.
- `load_persisted_session(project_root) -> (session|None, metadata|None)`: reconstruye la sesión desde
  `cookies.json`, incluyendo los `headers` guardados (relevante para que el `User-Agent` siga
  coincidiendo con el que validó el challenge de Cloudflare).
- `is_session_authenticated(session, base_url, retries=2) -> (bool, response)`: prueba `GET /donante/?busqueda=`, verifica que no redirija a `/login`, y reintenta ante challenges intermitentes de Cloudflare.
- `build_session_from_curl(curl_text) -> (CurlSession, base_url)` y `parse_curl_command(curl_text) -> dict`: parsean un curl "Copy as cURL" del navegador (headers + cookies).
- `read_curl_command(curl_file) -> str`: lee el curl desde archivo, stdin, o prompt interactivo.

### Transporte HTTP (`assets/curl_transport.py`)

- `CurlSession`: interfaz mínima estilo `requests.Session` (`.get()`, `.post()`, `.headers` dict, `.cookies`)
  cuyas llamadas ejecutan `curl` por subprocess (`-L --compressed --cookie-jar ...`) en vez de abrir la
  conexión TLS desde Python. Cada sesión usa su propio cookie-jar temporal en formato Netscape.
- `CookieJar`: vista sobre ese archivo; iterable (`cookie.name/value/domain/path/secure`), `.get_dict()`,
  `.set(name, value, domain=, path=, secure=)`.
- `CurlResponse`: `.status_code`, `.url` (URL final tras seguir redirecciones), `.text`, `.raise_for_status()`.
- `CurlError`: excepción para `curl` con código de salida distinto de 0, o HTTP >= 400 vía `raise_for_status()`.
