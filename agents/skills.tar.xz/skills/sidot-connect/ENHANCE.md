# ENHANCE: login por credenciales vía Playwright

Estado: **propuesto, no implementado**. Este documento describe una mejora pendiente para
`sidot-connect`, a implementar solo cuando se confirme explícitamente.

## Problema

`SidotClient.login()` (`assets/api.py`) intenta `GET /login` -> `POST /logon` con `SIDOT_USER`/`SIDOT_PWD`.
Ese flujo está bloqueado: SIDOT antepone a `/login` un challenge JS de Cloudflare ("Just a moment...",
403, header `Cf-Mitigated: challenge`) que ningún cliente sin motor JS puede resolver.

`assets/curl_transport.py` (ver `SKILL.md`) resolvió la mitad del problema: permite **reutilizar** una
sesión ya autenticada (cookies copiadas de un navegador real, vía `SIDOT_CURL` o
`sidot_login_from_curl.py`) sin que Cloudflare bloquee el cliente por fingerprint TLS. Pero `curl` no
puede **obtener** una sesión nueva desde cero con usuario/clave: no ejecuta JavaScript, así que no
puede resolver el challenge de Cloudflare ni completar el formulario de login por sí mismo. Hoy esa
sesión inicial la sigue teniendo que generar un humano copiando el curl desde su navegador.

## Propuesta

Usar Playwright (Chromium real) para hacer exactamente lo que hace un humano al loguearse, y extraer
la sesión resultante hacia el mismo formato que ya consume el resto del skill.

Nuevo script: `assets/sidot_login_playwright.py`

1. Lanza Chromium (Playwright), navega a `SIDOT_URL/login`.
2. Espera a que el challenge de Cloudflare se resuelva (esperar por un selector del formulario real,
   ej. `input[name=username]`, con timeout generoso).
3. Llena usuario/clave desde `SIDOT_USER`/`SIDOT_PWD` (`.env` del `--project-root`, igual que hoy) y
   envía el formulario.
4. Verifica login exitoso (URL ya no es `/login`, o aparece un elemento de página autenticada).
5. Extrae cookies vía `context.cookies()` (incluye `cf_clearance`, `__cf_bm`, `JSESSIONID`, con
   `domain`/`path`/`secure` reales) y el `User-Agent` real usado por Chromium.
6. Persiste todo en `doc/.sidot/session/cookies.json` con el mismo esquema que ya escriben
   `sidot_login.py` / `sidot_login_from_curl.py` (`base_url`, `authenticated`, `headers`, `cookies`,
   `source: "playwright"`).

Con esto, `build_authenticated_session()` (`assets/sidot_common.py`) recoge esa sesión igual que
recoge cualquier otra sesión persistida — **no requiere cambios** en `curl_transport.py` ni en los
scripts de búsqueda/catálogo. Playwright solo entra en juego para el handshake de login; toda la
navegación posterior (donante, extracciones, usuarios, hospitales) sigue vía `curl` subprocess, que es
mucho más liviano para volumen de requests.

## Dependencias: dónde quedan

Este repo ya tiene un precedente idéntico en `scripts/bancochile` (también usa Playwright). Se seguiría
el mismo esquema, aislado dentro de `agents/skills/sidot-connect/`:

- `assets/requirements.txt`: `playwright>=1.52.0` (el resto del skill no depende de pip, solo del
  binario `curl` del sistema).
- `assets/setup_env.sh`, análogo a `scripts/bancochile/setup_env.sh`:
  ```bash
  python3 -m venv .venv
  source .venv/bin/activate
  pip install -r requirements.txt
  python -m playwright install chromium
  ```
- `.venv/` vive dentro del skill (`agents/skills/sidot-connect/assets/.venv/`), nunca se comitea.
  Agregar la entrada correspondiente a `.gitignore`, igual que existe hoy
  `scripts/bancochile/.venv/`.
- El binario de Chromium que descarga `playwright install` no va al repo ni al `.venv`: Playwright lo
  cachea en `~/.cache/ms-playwright/` (Linux), fuera del proyecto — descarga única por máquina, no por
  proyecto.
- Solo `sidot_login_playwright.py` necesita correr dentro de ese `.venv`; el resto de los scripts del
  skill sigue usando el intérprete de sistema tal como hoy.

## Trade-offs

- Dependencia pesada nueva: paquete `playwright` + binario de Chromium (~150-300MB), solo para el
  script de login (no para el resto del skill).
- Login más lento (segundos, por levantar un browser) vs. milisegundos de `curl` — aceptable porque
  el login es esporádico, no por-request.
- Cloudflare también puede marcar Chromium headless por señales de automatización (aunque con mucho
  menor frecuencia que a `curl`/`requests` sin motor JS). Mitigación si aparece: usar
  `headless=False` con Xvfb, o el modo `--headless=new` de Chrome, que es menos detectable que el
  headless clásico.

## Próximo paso

Implementar `sidot_login_playwright.py` + `assets/requirements.txt` + `assets/setup_env.sh`, y sumar
la entrada a `.gitignore`, solo cuando se confirme explícitamente seguir adelante.
