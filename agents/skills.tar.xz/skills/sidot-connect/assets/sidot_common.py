#!/usr/bin/env python3
import json
import os
import shlex
import sys
import time
from pathlib import Path
from urllib.parse import urlsplit

from api import SidotClient, load_env_file, env_get, extract_csrf_token, DEFAULT_HEADERS
from curl_transport import CurlError, CurlSession

SIDOT_CURL_ENV_KEY = "SIDOT_CURL"


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def write_json(path: Path, payload: object) -> None:
    ensure_dir(path.parent)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def session_cookies_to_json(session) -> list[dict]:
    cookies: list[dict] = []
    for cookie in session.cookies:
        cookies.append(
            {
                "name": cookie.name,
                "value": cookie.value,
                "domain": cookie.domain,
                "path": cookie.path,
                "secure": cookie.secure,
            }
        )
    return cookies


def cookies_json_path(project_root: Path) -> Path:
    return project_root / "doc" / ".sidot" / "session" / "cookies.json"


def read_curl_env(project_root: Path, key: str = SIDOT_CURL_ENV_KEY) -> str | None:
    """Read a pasted curl command from the SIDOT_CURL env var or the project's .env file.

    Only strips a matching pair of outer quotes (the .env quoting convention);
    it never touches quotes inside the curl command itself, since those are
    significant to shlex when the curl text is later parsed.
    """
    value = os.environ.get(key)
    if value:
        return value

    env_path = project_root / ".env"
    if not env_path.exists():
        return None

    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        line_key, _, line_value = line.partition("=")
        if line_key.strip() != key:
            continue
        value = line_value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        return value or None

    return None


def read_curl_command(curl_file: str | None) -> str:
    """Read a browser 'Copy as cURL' command from a file, stdin, or an interactive prompt."""
    if curl_file:
        return Path(curl_file).read_text(encoding="utf-8")
    if not sys.stdin.isatty():
        return sys.stdin.read()

    print(
        "Pega el comando curl completo (ej. 'Copiar como cURL' desde el navegador, "
        "tomado justo después de iniciar sesión en SIDOT).\n"
        "Termina con una línea vacía:",
        file=sys.stderr,
    )
    lines: list[str] = []
    while True:
        try:
            line = input()
        except EOFError:
            break
        if not line.strip():
            break
        lines.append(line)
    return "\n".join(lines)


def parse_curl_command(curl_text: str) -> dict:
    """Parse a browser 'Copy as cURL' command into url/headers/cookie_header."""
    normalized = curl_text.replace("\\\n", " ").replace("\\\r\n", " ")
    tokens = shlex.split(normalized, posix=True)
    if not tokens or tokens[0] != "curl":
        raise RuntimeError("El texto pegado no parece un comando curl (debe iniciar con 'curl').")

    url = None
    headers: dict[str, str] = {}
    cookie_header = ""

    value_flags = {
        "-H", "--header",
        "-b", "--cookie",
        "-X", "--request",
        "-d", "--data", "--data-raw", "--data-binary", "--data-urlencode",
        "-A", "--user-agent",
        "-e", "--referer",
    }

    i = 1
    while i < len(tokens):
        token = tokens[i]
        if token in ("-H", "--header"):
            i += 1
            header_line = tokens[i]
            name, _, value = header_line.partition(":")
            name = name.strip()
            value = value.strip()
            if name.lower() == "cookie":
                cookie_header = value
            else:
                headers[name] = value
        elif token in ("-b", "--cookie"):
            i += 1
            cookie_header = tokens[i]
        elif token in ("-A", "--user-agent"):
            i += 1
            headers["User-Agent"] = tokens[i]
        elif token in ("-e", "--referer"):
            i += 1
            headers["Referer"] = tokens[i]
        elif token in value_flags:
            i += 1  # skip flag value we don't need (method/body/etc.)
        elif token.startswith("http://") or token.startswith("https://"):
            url = token
        elif token.startswith("-"):
            pass  # boolean flag (--compressed, -s, -k, etc.)
        i += 1

    if not url:
        raise RuntimeError("No se encontró una URL http(s) en el comando curl pegado.")

    return {"url": url, "headers": headers, "cookie_header": cookie_header}


def build_session_from_curl(curl_text: str) -> tuple[CurlSession, str]:
    """Build a CurlSession by replaying a pasted browser curl command's headers/cookies."""
    parsed = parse_curl_command(curl_text)
    url_parts = urlsplit(parsed["url"])
    base_url = f"{url_parts.scheme}://{url_parts.netloc}"

    session = CurlSession()
    session.headers.update(parsed["headers"])

    for pair in parsed["cookie_header"].split(";"):
        pair = pair.strip()
        if not pair or "=" not in pair:
            continue
        name, value = pair.split("=", 1)
        session.cookies.set(name.strip(), value.strip(), domain=url_parts.hostname)

    return session, base_url


def is_session_authenticated(session: CurlSession, base_url: str, retries: int = 2):
    """Probe an authenticated-only page to check the session is not redirected to /login.

    Cloudflare's JS challenge in front of SIDOT can trigger intermittently even for an
    already-authenticated session (observed: the exact same request failed, then
    succeeded seconds later with no change on our end), so retry briefly before
    concluding the session is actually invalid.
    """
    response = None
    for attempt in range(retries):
        response = session.get(f"{base_url}/donante/?busqueda=", timeout=30)
        authenticated = response.status_code == 200 and "/login" not in response.url.rstrip("/")
        if authenticated:
            return True, response
        if attempt + 1 < retries:
            time.sleep(1.5)
    return False, response


def load_persisted_session(project_root: Path):
    """Rebuild a CurlSession from a previously persisted doc/.sidot/session/cookies.json."""
    path = cookies_json_path(project_root)
    if not path.exists():
        return None, None

    data = json.loads(path.read_text(encoding="utf-8"))
    base_url = data.get("base_url")
    if not base_url:
        return None, None

    session = CurlSession()
    session.headers.update(data.get("headers") or DEFAULT_HEADERS)
    for cookie in data.get("cookies", []):
        session.cookies.set(
            cookie["name"],
            cookie["value"],
            domain=cookie.get("domain"),
            path=cookie.get("path", "/"),
            secure=cookie.get("secure", True),
        )
    return session, data


def persist_session_from_curl(project_root: Path, curl_text: str, source: str = "curl"):
    """Build a session from a pasted curl command, verify it, and persist it to cookies.json.

    Every script that calls build_authenticated_session picks up this same
    persisted session afterwards, so the curl only needs to be refreshed
    (not re-pasted per script) when the Cloudflare-issued cookies expire.
    """
    parsed = parse_curl_command(curl_text)
    session, base_url = build_session_from_curl(curl_text)
    authenticated, probe_response = is_session_authenticated(session, base_url)
    if not authenticated:
        raise RuntimeError(
            "La sesión del curl pegado no está autenticada (redirige a /login). "
            "Copia un curl nuevo desde el navegador justo después de iniciar sesión en SIDOT."
        )

    metadata = {
        "base_url": base_url,
        "authenticated": authenticated,
        "auth_url": probe_response.url,
        "status_code": probe_response.status_code,
        "source": source,
        "headers": parsed["headers"],
        "cookies": session_cookies_to_json(session),
    }
    write_json(cookies_json_path(project_root), metadata)
    (cookies_json_path(project_root).parent / "login_response.html").write_text(
        probe_response.text, encoding="utf-8"
    )
    return session, metadata


def build_session_from_curl_env(project_root: Path):
    """Build and persist a session from SIDOT_CURL (env var or .env), if set."""
    curl_text = read_curl_env(project_root)
    if not curl_text:
        return None, None

    try:
        return persist_session_from_curl(project_root, curl_text, source="curl_env")
    except RuntimeError as exc:
        raise RuntimeError(
            f"{SIDOT_CURL_ENV_KEY} está definido pero {exc} "
            f"Actualiza {SIDOT_CURL_ENV_KEY} en .env con un curl vigente."
        ) from exc


def build_authenticated_session(project_root: Path):
    """Get an authenticated SIDOT session shared by every script/method in this skill.

    Resolution order:
    1. Reuse the persisted session in doc/.sidot/session/cookies.json if still authenticated.
    2. Build and persist a session from SIDOT_CURL (env var or .env) if set.
    3. Fall back to credential login (GET /login -> POST /logon), which only works when
       Cloudflare is not showing a JS challenge on /login.
    """
    session, persisted = load_persisted_session(project_root)
    if session is not None:
        authenticated, _ = is_session_authenticated(session, persisted["base_url"])
        if authenticated:
            metadata = dict(persisted)
            metadata["reused_persisted_session"] = True
            return session, metadata

    session, metadata = build_session_from_curl_env(project_root)
    if session is not None:
        metadata["reused_persisted_session"] = False
        return session, metadata

    client = SidotClient.from_project_root(project_root)
    try:
        metadata = client.login()
    except CurlError as exc:
        raise RuntimeError(
            "Login por credenciales falló (posible challenge de Cloudflare en /login) y no hay "
            f"{SIDOT_CURL_ENV_KEY} configurado. Define {SIDOT_CURL_ENV_KEY} en .env con un curl "
            "pegado desde una sesión de navegador autenticada, o ejecuta sidot_login_from_curl.py."
        ) from exc
    metadata["source"] = "credentials"
    metadata["cookies"] = session_cookies_to_json(client.session)
    metadata["reused_persisted_session"] = False
    return client.session, metadata


__all__ = [
    "SidotClient",
    "SIDOT_CURL_ENV_KEY",
    "build_authenticated_session",
    "build_session_from_curl",
    "build_session_from_curl_env",
    "cookies_json_path",
    "ensure_dir",
    "is_session_authenticated",
    "load_persisted_session",
    "parse_curl_command",
    "persist_session_from_curl",
    "read_curl_command",
    "read_curl_env",
    "session_cookies_to_json",
    "write_json",
    "load_env_file",
    "env_get",
    "extract_csrf_token",
]
