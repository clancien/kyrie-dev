#!/usr/bin/env python3
"""Persist a SIDOT session from a browser-copied curl command.

Use this when `sidot_login.py` fails because Cloudflare shows a JS challenge
("Just a moment...", header `Cf-Mitigated: challenge`) in front of /login:
plain HTTP requests can't solve that challenge, but a real browser can.

Copy a curl command from the browser's network tab for any authenticated
SIDOT request (e.g. GET /donante/ or GET /pref/hospital/?pageIndex=0) taken
right after logging in, then run this script. It replays that request's
cookies/headers, verifies the session is actually authenticated, and saves it
to doc/.sidot/session/cookies.json — every other script in this skill reuses
that file automatically until it expires.
"""
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from sidot_common import cookies_json_path, ensure_dir, persist_session_from_curl, read_curl_command


def parse_args():
    parser = argparse.ArgumentParser(
        description="Persist a SIDOT session from a pasted curl command (Cloudflare challenge fallback)."
    )
    parser.add_argument(
        "--project-root",
        "--proyect-root",
        default=str(Path.cwd().resolve()),
        help="Project root path (default: current working directory).",
    )
    parser.add_argument(
        "--curl-file",
        default=None,
        help="Path to a file containing the curl command (default: prompt/stdin).",
    )
    parser.add_argument("--stdout", action="store_true", help="Print metadata JSON to stdout.")
    return parser.parse_args()


def main():
    args = parse_args()
    project_root = Path(args.project_root).resolve()
    ensure_dir(project_root / "doc" / ".sidot" / "session")

    curl_text = read_curl_command(args.curl_file)
    _, metadata = persist_session_from_curl(project_root, curl_text, source="curl")

    print(f"Sesion SIDOT persistida desde curl en {cookies_json_path(project_root)}")
    if args.stdout:
        print(json.dumps(metadata, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
