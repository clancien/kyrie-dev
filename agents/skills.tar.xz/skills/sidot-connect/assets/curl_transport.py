#!/usr/bin/env python3
"""Minimal requests.Session-like HTTP client backed by the system curl binary.

Cloudflare in front of SIDOT fingerprints the TLS/HTTP client: the system
`curl` binary passes its bot/JS-challenge check, while Python's `requests`
(urllib3/ssl) gets challenged even when replaying the exact same headers and
valid cf_clearance cookies copied straight from a browser (verified: the
same pasted curl command succeeds when run as-is, but fails when its
headers/cookies are replayed through requests.Session). This module keeps
the requests-like call sites elsewhere in the skill unchanged (`.get()`,
`.post()`, `.cookies`, `.headers`, `.raise_for_status()`) while routing
actual network I/O through curl subprocesses.
"""
import os
import subprocess
import tempfile
from pathlib import Path
from urllib.parse import urlencode


class CurlError(Exception):
    """Raised when curl exits non-zero, or via raise_for_status() for HTTP >= 400."""


class CurlResponse:
    def __init__(self, status_code: int, url: str, text: str):
        self.status_code = status_code
        self.url = url
        self.text = text

    def raise_for_status(self) -> None:
        if self.status_code >= 400:
            raise CurlError(f"{self.status_code} Error for url: {self.url}")


class _Cookie:
    def __init__(self, name: str, value: str, domain: str, path: str, secure: bool):
        self.name = name
        self.value = value
        self.domain = domain
        self.path = path
        self.secure = secure


class CookieJar:
    """Netscape-format cookie jar file that curl reads/writes directly via --cookie-jar."""

    def __init__(self, path: Path):
        self.path = path
        if not self.path.exists():
            self.path.write_text("# Netscape HTTP Cookie File\n", encoding="utf-8")

    def _read_rows(self) -> list[list[str]]:
        rows = []
        for raw_line in self.path.read_text(encoding="utf-8").splitlines():
            if not raw_line.strip() or raw_line.startswith("#"):
                continue
            fields = raw_line.split("\t")
            if len(fields) == 7:
                rows.append(fields)
        return rows

    def __iter__(self):
        for domain, _include_sub, path, secure, _expires, name, value in self._read_rows():
            yield _Cookie(name, value, domain, path, secure == "TRUE")

    def get_dict(self) -> dict:
        return {cookie.name: cookie.value for cookie in self}

    def set(self, name: str, value: str, domain: str | None = None, path: str = "/", secure: bool = True) -> None:
        domain = domain or ""
        if domain and not domain.startswith("."):
            domain = f".{domain}"
        rows = [row for row in self._read_rows() if row[5] != name]
        rows.append(
            [domain, "TRUE" if domain else "FALSE", path, "TRUE" if secure else "FALSE", "2145916800", name, value]
        )
        lines = ["# Netscape HTTP Cookie File"] + ["\t".join(row) for row in rows]
        self.path.write_text("\n".join(lines) + "\n", encoding="utf-8")


class CurlSession:
    """requests.Session-like object whose .get()/.post() shell out to the curl binary."""

    def __init__(self):
        self.headers: dict[str, str] = {}
        fd, jar_path = tempfile.mkstemp(prefix="sidot_cookiejar_", suffix=".txt")
        os.close(fd)
        self._jar_path = Path(jar_path)
        self._jar_path.write_text("# Netscape HTTP Cookie File\n", encoding="utf-8")
        self.cookies = CookieJar(self._jar_path)

    def __del__(self):
        try:
            self._jar_path.unlink(missing_ok=True)
        except OSError:
            pass

    def get(self, url: str, timeout: int = 30, headers: dict | None = None, **_kwargs) -> CurlResponse:
        return self._request("GET", url, headers=headers, timeout=timeout)

    def post(self, url: str, data=None, headers: dict | None = None, timeout: int = 30, **_kwargs) -> CurlResponse:
        return self._request("POST", url, data=data, headers=headers, timeout=timeout)

    def _request(self, method: str, url: str, data=None, headers: dict | None = None, timeout: int = 30) -> CurlResponse:
        body_fd, body_path = tempfile.mkstemp(prefix="sidot_body_")
        os.close(body_fd)
        try:
            cmd = [
                "curl", "-sS", "-L", "--compressed",
                "--cookie", str(self._jar_path),
                "--cookie-jar", str(self._jar_path),
                "--max-time", str(timeout),
                "-o", body_path,
                "-w", "%{http_code} %{url_effective}",
                "-X", method,
            ]
            for name, value in {**self.headers, **(headers or {})}.items():
                cmd += ["-H", f"{name}: {value}"]
            if data is not None:
                if isinstance(data, (dict, list, tuple)):
                    data = urlencode(data)
                cmd += ["--data", data]
            cmd.append(url)

            try:
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout + 10)
            except subprocess.TimeoutExpired as exc:
                raise CurlError(f"curl timed out after {timeout}s for {url}") from exc
            if result.returncode != 0:
                raise CurlError(f"curl failed (exit {result.returncode}) for {url}: {result.stderr.strip()}")

            status_text, _, final_url = result.stdout.strip().partition(" ")
            body = Path(body_path).read_text(encoding="utf-8", errors="replace")
            return CurlResponse(int(status_text or "0"), final_url or url, body)
        finally:
            Path(body_path).unlink(missing_ok=True)


__all__ = ["CurlSession", "CurlResponse", "CurlError", "CookieJar"]
